// ==========================================
// SITE SETTINGS & ADS MANAGER
// ==========================================
// Update this file to change social links, ads, and site info.

export const SITE_SETTINGS = {
  // 1. General Info
  name: "CricFocus",
  description: "The sharpest eye on the game. Elite analysis for the modern fan.",
  contactEmail: "contact@cricfocus.com",

  // 2. Social Media Links
  socials: {
    instagram: "https://www.instagram.com/mranasansari208",
    twitter: "https://twitter.com/",
    facebook: "https://www.facebook.com/",
    youtube: "https://www.youtube.com/",
    whatsapp: "https://whatsapp.com/",
    telegram: "https://telegram.org/",
  },

  // 3. Sidebar Features (Fill empty space)
  sidebar: {
    showPoll: true,
    showNewsletter: true,
    showMatchSchedule: true,
    poll: {
      question: "Who will win the 2025 Champions Trophy?",
      options: ["India", "Australia", "England", "Pakistan"]
    }
  },

  // 4. Advertisement Slots (Google AdSense, etc.)
  // We have left these empty so no empty boxes appear on the site.
  // To add ads later, paste your HTML/Script code inside the quotes.
  ads: {
    headerAd: "", 
    
    sidebarAd: "", 
    
    articleInlineAd: "", 
  }
};