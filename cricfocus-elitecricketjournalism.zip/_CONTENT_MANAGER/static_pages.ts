import { StaticPage } from '../types';

// ==========================================
// STATIC PAGES MANAGER
// ==========================================

export const STATIC_PAGES: Record<string, StaticPage> = {
  
  rankings: {
    title: "ICC Team Rankings",
    content: `
      <p class="mb-6">Official International Cricket Council (ICC) team rankings. Last updated: February 2025.</p>
      
      <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
        
        <div>
          <h3 class="text-xl font-bold mb-4 border-b-2 border-black pb-2">Test Rankings</h3>
          <table class="w-full text-left border-collapse text-sm">
            <tr class="bg-gray-100"><th class="py-2 px-2">Pos</th><th>Team</th><th>Rating</th></tr>
            <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">1</td><td>Australia</td><td>124</td></tr>
            <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">2</td><td>India</td><td>120</td></tr>
            <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">3</td><td>South Africa</td><td>105</td></tr>
            <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">4</td><td>England</td><td>103</td></tr>
            <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">5</td><td>New Zealand</td><td>96</td></tr>
          </table>
        </div>

        <div>
          <h3 class="text-xl font-bold mb-4 border-b-2 border-black pb-2">ODI Rankings</h3>
          <table class="w-full text-left border-collapse text-sm">
            <tr class="bg-gray-100"><th class="py-2 px-2">Pos</th><th>Team</th><th>Rating</th></tr>
            <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">1</td><td>India</td><td>118</td></tr>
            <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">2</td><td>Australia</td><td>113</td></tr>
            <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">3</td><td>Pakistan</td><td>109</td></tr>
            <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">4</td><td>South Africa</td><td>106</td></tr>
            <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">5</td><td>New Zealand</td><td>101</td></tr>
          </table>
        </div>

        <div>
          <h3 class="text-xl font-bold mb-4 border-b-2 border-black pb-2">T20I Rankings</h3>
          <table class="w-full text-left border-collapse text-sm">
             <tr class="bg-gray-100"><th class="py-2 px-2">Pos</th><th>Team</th><th>Rating</th></tr>
             <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">1</td><td>India</td><td>267</td></tr>
             <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">2</td><td>Australia</td><td>259</td></tr>
             <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">3</td><td>England</td><td>253</td></tr>
             <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">4</td><td>West Indies</td><td>251</td></tr>
             <tr class="border-b border-gray-100"><td class="py-2 px-2 font-bold">5</td><td>New Zealand</td><td>247</td></tr>
          </table>
        </div>

      </div>
    `
  },

  series: {
    title: "International Cricket Calendar 2025",
    content: `
      <div class="space-y-12">
        <p class="text-lg text-gray-700 italic border-l-4 border-news-accent pl-4">
          Key upcoming tournaments and bilateral series.
        </p>
        
        <div class="bg-gray-50 p-6 border border-gray-200">
           <h3 class="font-bold text-lg mb-4 text-news-accent">Major Events</h3>
           <ul class="list-disc ml-5 space-y-3">
             <li><strong>ICC Champions Trophy</strong> (Feb - March 2025)</li>
             <li><strong>World Test Championship Final</strong> (June 2025)</li>
             <li><strong>Indian Premier League (IPL)</strong> (March - May 2025)</li>
           </ul>
        </div>

        <div class="bg-white p-6 border border-gray-200">
           <h3 class="font-bold text-lg mb-4">Upcoming Series</h3>
           <ul class="list-disc ml-5 space-y-3">
             <li>England tour of India (5 T20Is, 3 ODIs)</li>
             <li>South Africa vs Pakistan (Test Series)</li>
             <li>The Ashes: Australia vs England (Winter 2025/26)</li>
           </ul>
        </div>
      </div>
    `
  },

  about: {
    title: "About Us",
    content: `
      <p class="text-xl leading-relaxed text-gray-700 mb-6">
        Welcome to <strong>CricFocus</strong>, your digital destination for authentic cricket journalism, live scores, and in-depth statistical analysis.
      </p>
      
      <h3 class="text-2xl font-bold mt-8 mb-4">Our Mission</h3>
      <p>
        We are a digital-first sports media platform built for the modern cricket fan. In an age of clickbait, we strive for accuracy, depth, and nuance. Our mission is to provide fans with a platform that goes beyond the scorecard, offering deep dives into technique, strategy, and cricket culture.
      </p>

      <h3 class="text-2xl font-bold mt-8 mb-4">What We Offer</h3>
      <ul class="list-disc ml-6 space-y-2 mb-6">
        <li><strong>Live Coverage:</strong> Real-time ball-by-ball commentary and score updates.</li>
        <li><strong>Expert Analysis:</strong> Tactical breakdowns of matches and player techniques.</li>
        <li><strong>Player Profiles:</strong> Comprehensive biographies and career statistics.</li>
        <li><strong>Global Reach:</strong> Coverage of all major ICC events, domestic leagues, and bilateral series.</li>
      </ul>

      <h3 class="text-2xl font-bold mt-8 mb-4">Contact Information</h3>
      <p>
        For editorial inquiries, advertising opportunities, or feedback, please visit our <a href="#/contact" class="text-news-accent underline">Contact Us</a> page.
      </p>
    `
  },

  privacy: {
    title: "Privacy Policy",
    content: `
      <p class="mb-4"><strong>Effective Date: February 10, 2025</strong></p>
      
      <p class="mb-6">CricFocus ("we", "our", or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and safeguard your information when you visit our website.</p>
      
      <h3 class="text-xl font-bold mt-8 mb-4">1. Information We Collect</h3>
      <p class="mb-4">We may collect the following types of information:</p>
      <ul class="list-disc ml-6 space-y-2 mb-6">
        <li><strong>Personal Information:</strong> Name and email address when you voluntarily subscribe to our newsletter or contact us.</li>
        <li><strong>Usage Data:</strong> Information on how you interact with the site, such as pages visited, time spent, and referring links, collected via analytics tools.</li>
      </ul>

      <h3 class="text-xl font-bold mt-8 mb-4">2. How We Use Your Information</h3>
      <p class="mb-4">We use the collected data to:</p>
      <ul class="list-disc ml-6 space-y-2 mb-6">
        <li>Deliver and improve our content and services.</li>
        <li>Send newsletters and updates (only if you have opted in).</li>
        <li>Analyze website traffic to understand user preferences and trends.</li>
      </ul>

      <h3 class="text-xl font-bold mt-8 mb-4">3. Cookies and Tracking</h3>
      <p class="mb-4">
        We use cookies to enhance your browsing experience. Cookies are small text files stored on your device. We may use both session cookies (which expire once you close your web browser) and persistent cookies (which stay on your device for a set period) to remember your preferences and improve load times.
      </p>

      <h3 class="text-xl font-bold mt-8 mb-4">4. Third-Party Advertisers</h3>
      <p class="mb-4">
        We may work with third-party advertising networks to display ads. These networks may use cookies and web beacons to collect non-personal data about your activities on this and other websites to provide you with targeted advertising based on your interests.
      </p>

      <h3 class="text-xl font-bold mt-8 mb-4">5. Data Security</h3>
      <p class="mb-4">
        We implement appropriate technical and organizational measures to protect your personal data against unauthorized access, alteration, disclosure, or destruction. However, please note that no method of transmission over the Internet is 100% secure.
      </p>

      <h3 class="text-xl font-bold mt-8 mb-4">6. Contact Us</h3>
      <p class="mb-4">
        If you have questions about this Privacy Policy, please contact us at <a href="mailto:privacy@cricfocus.com" class="text-news-accent underline">privacy@cricfocus.com</a>.
      </p>
    `
  },

  terms: {
    title: "Terms and Conditions",
    content: `
      <p class="mb-4"><strong>Last Updated: February 2025</strong></p>
      <p>Welcome to CricFocus! These terms and conditions outline the rules and regulations for the use of our Website.</p>
      
      <h3 class="mt-4 font-bold">1. Acceptance of Terms</h3>
      <p>By accessing this website, we assume you accept these terms and conditions. Do not continue to use CricFocus if you do not agree to take all of the terms and conditions stated on this page.</p>

      <h3 class="mt-4 font-bold">2. Intellectual Property Rights</h3>
      <p>Unless otherwise stated, CricFocus and/or its licensors own the intellectual property rights for all material on CricFocus. All intellectual property rights are reserved. You may access this from CricFocus for your own personal use subjected to restrictions set in these terms and conditions.</p>

      <h3 class="mt-4 font-bold">3. Restrictions</h3>
      <p>You are specifically restricted from all of the following:</p>
      <ul class="list-disc ml-5 mb-4">
        <li>Publishing any Website material in any other media without prior consent.</li>
        <li>Selling, sublicensing and/or otherwise commercializing any Website material.</li>
        <li>Using this Website in any way that is or may be damaging to this Website.</li>
      </ul>

      <h3 class="mt-4 font-bold">4. Limitation of Liability</h3>
      <p>In no event shall CricFocus, nor any of its officers, directors, and employees, be held liable for anything arising out of or in any way connected with your use of this Website.</p>
    `
  },

  disclaimer: {
    title: "Disclaimer",
    content: `
      <p class="mb-4">The information provided by CricFocus ("we," "us," or "our") on our website is for general informational purposes only. All information on the Site is provided in good faith, however we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability or completeness of any information on the Site.</p>
      
      <div class="bg-gray-100 p-4 border-l-4 border-news-accent my-6">
        <h4 class="font-bold text-news-ink uppercase text-xs tracking-wider mb-2">Demonstration Notice</h4>
        <p class="text-sm">This website is a demonstration project. Match scores, commentary, player statistics, and certain news articles are simulated or mock data intended for display purposes only. They do not reflect real-time real-world events.</p>
      </div>

      <h3 class="mt-4 font-bold">External Links Disclaimer</h3>
      <p>The Site may contain (or you may be sent through the Site) links to other websites or content belonging to or originating from third parties or links to websites and features in banners or other advertising. Such external links are not investigated, monitored, or checked for accuracy, adequacy, validity, reliability, availability or completeness by us.</p>
      
      <h3 class="mt-4 font-bold">Professional Disclaimer</h3>
      <p>The Site cannot and does not contain professional sports betting advice. The cricket information is provided for general informational and entertainment purposes only and is not a substitute for professional advice. Accordingly, before taking any actions based upon such information, we encourage you to consult with the appropriate professionals.</p>
    `
  }
};