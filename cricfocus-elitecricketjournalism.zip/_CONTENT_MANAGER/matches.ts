import { Match, MatchFormat, MatchStatus, Commentary } from '../types';

// ==========================================
// MATCHES & SCORES MANAGER
// ==========================================

export const TEAMS_DATA = {
  IND: { id: 'ind', name: 'India', shortName: 'IND', flag: 'https://flagcdn.com/in.svg', color: '#138808' },
  AUS: { id: 'aus', name: 'Australia', shortName: 'AUS', flag: 'https://flagcdn.com/au.svg', color: '#FFCD00' },
  ENG: { id: 'eng', name: 'England', shortName: 'ENG', flag: 'https://flagcdn.com/gb-eng.svg', color: '#CE1124' },
  SA: { id: 'sa', name: 'South Africa', shortName: 'SA', flag: 'https://flagcdn.com/za.svg', color: '#007A4D' },
  NZ: { id: 'nz', name: 'New Zealand', shortName: 'NZ', flag: 'https://flagcdn.com/nz.svg', color: '#000000' },
  PAK: { id: 'pak', name: 'Pakistan', shortName: 'PAK', flag: 'https://flagcdn.com/pk.svg', color: '#00401A' },
  WI: { id: 'wi', name: 'West Indies', shortName: 'WI', flag: 'https://flagcdn.com/bb.svg', color: '#7B001C' }, // Using Barbados flag as proxy for WI in mock
  USA: { id: 'usa', name: 'USA', shortName: 'USA', flag: 'https://flagcdn.com/us.svg', color: '#3C3B6E' },
  AFG: { id: 'afg', name: 'Afghanistan', shortName: 'AFG', flag: 'https://flagcdn.com/af.svg', color: '#009900' }
};

export const MATCHES_DATA: Match[] = [
  // 1. HEADLINE MATCH: IND vs AUS (Test)
  {
    id: 'm1',
    format: MatchFormat.TEST,
    status: MatchStatus.LIVE,
    teamHome: TEAMS_DATA.AUS,
    teamAway: TEAMS_DATA.IND,
    scoreHome: { runs: 187, wickets: 3, overs: 54.2, battingTeamId: 'aus' },
    // scoreAway: undefined (India hasn't batted yet or Aus is batting first inning)
    venue: 'Perth Stadium, Perth',
    startTime: new Date().toISOString(),
    summary: 'Day 1 - Session 2: AUS elect to bat',
    result: 'Smith 42*, Labuschagne 65*',
    toss: 'Australia won the toss and elected to bat first.',
    pitchReport: 'A classic Perth surface with plenty of pace and bounce. Cracks are starting to open up, which might interest the spinners later in the game.',
    weather: {
      temp: '32°C',
      condition: 'Sunny',
      humidity: '45%'
    },
    currentBatter: 'M. Labuschagne',
    currentBowler: 'J. Bumrah'
  },
  // 2. ENG vs WI (Test)
  {
    id: 'm2',
    format: MatchFormat.TEST,
    status: MatchStatus.LIVE,
    teamHome: TEAMS_DATA.ENG,
    teamAway: TEAMS_DATA.WI,
    scoreHome: { runs: 416, wickets: 10, overs: 88.3, battingTeamId: 'eng' },
    scoreAway: { runs: 45, wickets: 1, overs: 14.0, battingTeamId: 'wi' },
    venue: 'Trent Bridge, Nottingham',
    startTime: new Date().toISOString(),
    summary: 'Day 2 - WI trail by 371 runs',
    toss: 'England won the toss and elected to bat.',
    pitchReport: 'Green top offering movement for the seamers early on. Batting will get easier as the sun comes out.',
    weather: {
      temp: '18°C',
      condition: 'Cloudy',
      humidity: '75%'
    }
  },
  // 3. T20 World Cup: USA vs SA
  {
    id: 'm3',
    format: MatchFormat.T20,
    status: MatchStatus.COMPLETED,
    teamHome: TEAMS_DATA.USA,
    teamAway: TEAMS_DATA.SA,
    scoreHome: { runs: 176, wickets: 6, overs: 20, battingTeamId: 'usa' },
    scoreAway: { runs: 194, wickets: 4, overs: 20, battingTeamId: 'sa' },
    venue: 'Sir Vivian Richards Stadium, Antigua',
    startTime: new Date(Date.now() - 86400000).toISOString(),
    result: 'South Africa won by 18 runs',
    summary: 'Super 8s',
    toss: 'South Africa won the toss and elected to bat.',
    weather: {
      temp: '28°C',
      condition: 'Clear',
      humidity: '80%'
    }
  },
  // 4. T20 World Cup: AFG vs IND
  {
    id: 'm4',
    format: MatchFormat.T20,
    status: MatchStatus.UPCOMING,
    teamHome: TEAMS_DATA.AFG,
    teamAway: TEAMS_DATA.IND,
    scoreHome: { runs: 0, wickets: 0, overs: 0, battingTeamId: 'afg' },
    venue: 'Kensington Oval, Barbados',
    startTime: new Date(Date.now() + 43200000).toISOString(),
    summary: 'Starts at 8:00 PM IST',
    result: 'Match yet to begin',
    pitchReport: 'Dry surface, expected to aid spinners. Dew might play a role in the second innings.',
    weather: {
      temp: '26°C',
      condition: 'Rain',
      humidity: '90%'
    }
  },
  // 5. PAK vs NZ (ODI Series)
  {
    id: 'm5',
    format: MatchFormat.ODI,
    status: MatchStatus.COMPLETED,
    teamHome: TEAMS_DATA.PAK,
    teamAway: TEAMS_DATA.NZ,
    scoreHome: { runs: 282, wickets: 10, overs: 48.3, battingTeamId: 'pak' },
    scoreAway: { runs: 286, wickets: 3, overs: 46.1, battingTeamId: 'nz' },
    venue: 'Gaddafi Stadium, Lahore',
    startTime: new Date(Date.now() - 172800000).toISOString(),
    result: 'New Zealand won by 7 wickets',
    summary: 'Series leveled 1-1',
    toss: 'New Zealand won the toss and elected to bowl.',
    weather: {
      temp: '34°C',
      condition: 'Sunny',
      humidity: '30%'
    }
  }
];

export const COMMENTARY_DATA: Commentary[] = [
  {
    id: 'c1',
    ball: 54.2,
    runs: 4,
    isWicket: false,
    isBoundary: true,
    bowler: 'Bumrah',
    batsman: 'Smith',
    text: 'FOUR! Controlled aggression. Smith waits for the back-of-length delivery and punches it off the back foot through point. No one moved.',
    timestamp: 'Now'
  },
  {
    id: 'c2',
    ball: 54.1,
    runs: 0,
    isWicket: false,
    isBoundary: false,
    bowler: 'Bumrah',
    batsman: 'Smith',
    text: 'Good length, jagging back in sharply! Smith gets an inside edge onto the pads. Stifled appeal, but clearly going down leg.',
    timestamp: '1 min ago'
  },
  {
    id: 'c3',
    ball: 54.0,
    runs: 0,
    isWicket: false,
    isBoundary: false,
    bowler: 'Bumrah',
    batsman: 'Smith',
    text: 'Starts the new spell with a beauty! Seams away from the right hander, beating the outside edge by a whisker.',
    timestamp: '2 mins ago'
  }
];