import { Video } from '../types';

// ==========================================
// VIDEO MANAGER
// ==========================================
// Add your videos below.

export const VIDEOS_DATA: Video[] = [
  {
    id: 'v1',
    title: 'Street Cricket: The Future Stars',
    // Authentic street cricket vibe
    thumbnailUrl: 'https://images.unsplash.com/photo-1593341646782-e0b495cffd32?q=80&w=1000&auto=format&fit=crop',
    // Mixkit royalty-free clip: Kids playing
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-kids-playing-cricket-on-the-beach-40063-large.mp4',
    duration: '00:18',
    publishedAt: '3 hours ago'
  },
  {
    id: 'v2',
    title: 'Slow Motion: The Perfect Delivery',
    // Bowler running in
    thumbnailUrl: 'https://images.unsplash.com/photo-1531415074968-0559f3f13e5e?q=80&w=1000&auto=format&fit=crop',
    // Mixkit royalty-free clip: Bowling action
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-cricket-player-bowling-in-a-match-40069-large.mp4',
    duration: '00:15',
    publishedAt: '6 hours ago'
  },
  {
    id: 'v3',
    title: 'Training Day: Power Hitting',
    // Batsman focused
    thumbnailUrl: 'https://images.unsplash.com/photo-1624526267942-ab0ff8a3e972?q=80&w=1000&auto=format&fit=crop',
    // Mixkit royalty-free clip: Batting shot
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-cricket-batsman-hitting-the-ball-40071-large.mp4',
    duration: '00:12',
    publishedAt: '1 day ago'
  }
];