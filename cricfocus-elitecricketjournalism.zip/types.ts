export enum MatchFormat {
  TEST = 'TEST',
  ODI = 'ODI',
  T20 = 'T20'
}

export enum MatchStatus {
  LIVE = 'LIVE',
  COMPLETED = 'COMPLETED',
  UPCOMING = 'UPCOMING'
}

export interface Player {
  id: string;
  name: string;
  role: string;
  image: string;
}

export interface Team {
  id: string;
  name: string;
  shortName: string;
  flag: string; // URL to flag image
  color: string;
}

export interface Score {
  runs: number;
  wickets: number;
  overs: number;
  battingTeamId: string;
}

export interface MatchWeather {
  temp: string;
  condition: 'Sunny' | 'Cloudy' | 'Rain' | 'Overcast' | 'Clear';
  humidity: string;
}

export interface Match {
  id: string;
  format: MatchFormat;
  status: MatchStatus;
  teamHome: Team;
  teamAway: Team;
  scoreHome: Score;
  scoreAway?: Score; // Optional if away hasn't batted or it's not their turn in simple view
  venue: string;
  startTime: string; // ISO string
  result?: string; // "India won by 4 wickets"
  summary: string; // "Stumps - Day 2" or "Innings Break"
  
  // New Live Features
  toss?: string;
  pitchReport?: string;
  weather?: MatchWeather;
  currentBatter?: string;
  currentBowler?: string;
}

export interface Commentary {
  id: string;
  ball: number; // e.g., 14.2
  runs: number | string; // Runs scored on this ball or 'W'
  isWicket: boolean;
  isBoundary: boolean;
  bowler: string;
  batsman: string;
  text: string;
  timestamp: string;
}

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  author: string;
  publishedAt: string;
  imageUrl: string;
  category: string;
  content?: string; // HTML string
  
  // New fields for Reviews
  rating?: number; // 0 to 10 score
  pros?: string[]; // List of good points
  cons?: string[]; // List of bad points
}

export interface Video {
  id: string;
  title: string;
  thumbnailUrl: string;
  videoUrl: string; // YouTube link or similar
  duration: string;
  publishedAt: string;
}

export interface StaticPage {
  title: string;
  content: string; // HTML allowed
}