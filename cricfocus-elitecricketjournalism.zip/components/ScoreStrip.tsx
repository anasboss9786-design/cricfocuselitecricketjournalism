import React from 'react';
import { Match, MatchStatus } from '../types';
import { useNavigate } from 'react-router-dom';
import { CircleDot } from 'lucide-react';

interface ScoreStripProps {
  matches: Match[];
}

const ScoreStrip: React.FC<ScoreStripProps> = ({ matches }) => {
  const navigate = useNavigate();

  return (
    <div className="w-full bg-news-ink text-white border-b border-gray-800 overflow-x-auto no-scrollbar">
      <div className="flex divide-x divide-gray-800">
        <div className="flex-shrink-0 px-4 py-3 flex items-center bg-news-accent text-white font-bold text-xs uppercase tracking-widest">
          <CircleDot className="w-3 h-3 mr-2 animate-pulse" />
          Live Center
        </div>
        {matches.map((match) => (
          <button
            key={match.id}
            onClick={() => navigate(`/match/${match.id}`)}
            className="flex-shrink-0 px-6 py-2 min-w-[200px] hover:bg-gray-900 transition-colors text-left group"
          >
            <div className="flex items-center justify-between text-[10px] uppercase tracking-wider text-gray-400 mb-1">
              <span>{match.format} &bull; {match.venue.split(',')[0]}</span>
              {match.status === MatchStatus.LIVE && <span className="text-news-accent font-bold">Live</span>}
            </div>
            
            <div className="flex flex-col space-y-1">
              <div className="flex justify-between items-center">
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-sm">{match.teamHome.shortName}</span>
                  {match.scoreHome && (
                    <span className="text-xs font-mono text-gray-300">
                      {match.scoreHome.runs}/{match.scoreHome.wickets} <span className="text-gray-500">({match.scoreHome.overs})</span>
                    </span>
                  )}
                </div>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-sm text-gray-400 group-hover:text-white transition-colors">{match.teamAway.shortName}</span>
                  {match.scoreAway && (
                    <span className="text-xs font-mono text-gray-300">
                      {match.scoreAway.runs}/{match.scoreAway.wickets} <span className="text-gray-500">({match.scoreAway.overs})</span>
                    </span>
                  )}
                </div>
              </div>
            </div>
            
            <div className="mt-1 text-[10px] text-gray-500 truncate">
               {match.result || match.summary}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default ScoreStrip;
