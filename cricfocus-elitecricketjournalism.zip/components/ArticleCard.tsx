import React, { useState } from 'react';
import { Article } from '../types';
import { useNavigate } from 'react-router-dom';
import { Clock, Star, Heart } from 'lucide-react';

interface ArticleCardProps {
  article: Article;
  variant?: 'featured' | 'standard' | 'compact';
}

const ArticleCard: React.FC<ArticleCardProps> = ({ article, variant = 'standard' }) => {
  const navigate = useNavigate();
  const [likes, setLikes] = useState(Math.floor(Math.random() * 500) + 50); // Random initial likes
  const [liked, setLiked] = useState(false);

  const handleClick = (e: React.MouseEvent) => {
    // Prevent navigation if clicking the like button
    if ((e.target as HTMLElement).closest('button')) return;
    navigate(`/article/${article.id}`);
  };

  const toggleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    setLiked(!liked);
    setLikes(prev => liked ? prev - 1 : prev + 1);
  };

  const RatingBadge = () => {
    if (!article.rating) return null;
    return (
      <div className="absolute top-2 right-2 bg-news-accent text-white px-2 py-1 text-xs font-bold shadow-md z-10 flex items-center rounded-sm">
        <Star className="w-3 h-3 mr-1 fill-current" />
        {article.rating}/10
      </div>
    );
  };

  const LikeButton = ({ className = "" }) => (
    <button 
      onClick={toggleLike}
      className={`flex items-center space-x-1 group/btn transition-colors ${className}`}
    >
      <Heart className={`w-4 h-4 transition-all duration-300 ${liked ? 'fill-red-500 text-red-500 scale-110' : 'text-gray-400 group-hover/btn:text-red-400'}`} />
      <span className={`text-xs font-medium ${liked ? 'text-red-500' : 'text-gray-400 group-hover/btn:text-red-400'}`}>
        {likes}
      </span>
    </button>
  );

  if (variant === 'featured') {
    return (
      <div onClick={handleClick} className="group cursor-pointer relative w-full h-[400px] sm:h-[500px] overflow-hidden rounded-lg shadow-xl mb-8 transform transition-all duration-500 hover:shadow-2xl">
        <RatingBadge />
        <img 
          src={article.imageUrl} 
          alt={article.title} 
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-90"></div>
        <div className="absolute bottom-0 left-0 p-6 sm:p-10 w-full sm:w-3/4">
          <span className="inline-block px-3 py-1 mb-4 text-xs font-bold tracking-widest text-white uppercase bg-news-accent rounded-full shadow-lg">
            {article.category}
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white leading-tight mb-3 group-hover:text-gray-100 transition-colors">
            {article.title}
          </h2>
          <p className="text-gray-300 mb-6 line-clamp-2 font-sans text-lg hidden sm:block">
            {article.excerpt}
          </p>
          <div className="flex items-center justify-between">
            <div className="flex items-center text-sm text-gray-400 space-x-4">
              <span className="uppercase tracking-wider font-bold text-white">{article.author}</span>
              <span className="flex items-center"><Clock className="w-3 h-3 mr-1" /> {article.publishedAt}</span>
            </div>
            {/* Featured Like Button needs higher contrast */}
            <button 
              onClick={toggleLike}
              className="flex items-center space-x-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full hover:bg-white/20 transition-all"
            >
               <Heart className={`w-5 h-5 transition-all ${liked ? 'fill-red-500 text-red-500' : 'text-white'}`} />
               <span className="text-white font-bold text-sm">{likes}</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <div onClick={handleClick} className="group cursor-pointer flex gap-4 py-4 border-b border-news-border dark:border-gray-800 last:border-0 relative hover:bg-gray-50 dark:hover:bg-white/5 transition-colors px-2 rounded-md">
         <div className="flex-1">
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold text-news-accent uppercase tracking-wider mb-1 flex items-center">
              {article.category}
              {article.rating && <span className="flex items-center text-news-ink dark:text-gray-300 ml-2"><Star className="w-3 h-3 mr-1 fill-current" /> {article.rating}</span>}
            </span>
          </div>
          <h3 className="text-md font-serif font-bold text-news-ink dark:text-gray-100 leading-tight mb-1 group-hover:text-news-accent transition-colors">
            {article.title}
          </h3>
          <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 mt-2">
            <span>{article.publishedAt}</span>
            <LikeButton />
          </div>
        </div>
      </div>
    );
  }

  // Standard
  return (
    <div onClick={handleClick} className="group cursor-pointer flex flex-col mb-8 relative bg-white dark:bg-news-card rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 border border-transparent hover:border-news-border dark:hover:border-gray-700">
      <div className="w-full aspect-video overflow-hidden relative">
        <RatingBadge />
        <img 
          src={article.imageUrl} 
          alt={article.title} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        {/* Overlay on hover */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300"></div>
      </div>
      <div className="p-5">
        <span className="text-xs font-bold text-news-accent uppercase tracking-wider mb-2 block">
          {article.category}
        </span>
        <h3 className="text-xl sm:text-2xl font-serif font-bold text-news-ink dark:text-white leading-tight mb-3 group-hover:text-news-accent transition-colors">
          {article.title}
        </h3>
        <p className="text-gray-600 dark:text-gray-300 mb-4 font-sans leading-relaxed line-clamp-3 text-sm sm:text-base">
          {article.excerpt}
        </p>
        <div className="flex items-center justify-between border-t border-gray-100 dark:border-gray-700 pt-4">
          <div className="flex items-center text-xs sm:text-sm text-gray-500 dark:text-gray-400 space-x-3">
            <span className="font-medium text-news-ink dark:text-gray-200">{article.author}</span>
            <span>&bull;</span>
            <span>{article.publishedAt}</span>
          </div>
          <LikeButton className="bg-gray-50 dark:bg-gray-800 px-3 py-1 rounded-full" />
        </div>
      </div>
    </div>
  );
};

export default ArticleCard;