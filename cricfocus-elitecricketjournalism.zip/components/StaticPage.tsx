import React from 'react';
import { STATIC_PAGES } from '../_CONTENT_MANAGER/static_pages';
import AdUnit from './AdUnit';
import { SITE_SETTINGS } from '../_CONTENT_MANAGER/settings';

interface StaticPageProps {
  pageKey: string;
}

const StaticPage: React.FC<StaticPageProps> = ({ pageKey }) => {
  const pageData = STATIC_PAGES[pageKey];

  if (!pageData) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center text-gray-500">
        <h1 className="text-2xl font-bold mb-2">Page Not Found</h1>
        <p>The content you are looking for does not exist.</p>
      </div>
    );
  }

  return (
    <div className="bg-news-paper min-h-screen">
       {/* Header Ad */}
       <div className="max-w-7xl mx-auto px-4">
        <AdUnit code={SITE_SETTINGS.ads.headerAd} />
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        <h1 className="text-4xl font-serif font-bold text-news-ink mb-8 border-b-2 border-black pb-4">
          {pageData.title}
        </h1>
        
        <div 
          className="prose prose-lg prose-stone font-serif text-gray-800"
          dangerouslySetInnerHTML={{ __html: pageData.content }}
        />
      </div>
    </div>
  );
};

export default StaticPage;
