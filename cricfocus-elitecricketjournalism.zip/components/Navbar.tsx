import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Search, Globe, Aperture, Moon, Sun } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const { language, setLanguage, t } = useLanguage();
  const { theme, toggleTheme } = useTheme();

  const isActive = (path: string) => location.pathname === path ? "border-news-accent text-news-accent" : "border-transparent text-gray-500 dark:text-gray-400 hover:text-news-ink dark:hover:text-white";

  return (
    <nav className="bg-white dark:bg-news-dark border-b border-news-border dark:border-gray-800 sticky top-0 z-40 font-sans shadow-sm transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo & Desktop Nav */}
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link to="/" className="font-sans font-black text-2xl tracking-tighter text-news-ink dark:text-white flex items-center uppercase italic">
                <Aperture className="w-6 h-6 text-news-accent mr-2" />
                Cric<span className="text-news-accent">Focus</span>
              </Link>
            </div>
            <div className="hidden lg:ml-10 lg:flex lg:space-x-8">
              <Link to="/" className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-bold uppercase tracking-wide transition-colors ${isActive('/')}`}>
                {t('home')}
              </Link>
              <Link to="/scores" className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-bold uppercase tracking-wide transition-colors ${isActive('/scores')}`}>
                {t('liveScore')}
              </Link>
              <Link to="/" className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-bold uppercase tracking-wide transition-colors ${isActive('/news')}`}>
                {t('news')}
              </Link>
              <Link to="/players" className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-bold uppercase tracking-wide transition-colors ${isActive('/players')}`}>
                {t('players')}
              </Link>
              <Link to="/about" className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-bold uppercase tracking-wide transition-colors ${isActive('/about')}`}>
                {t('about')}
              </Link>
              <Link to="/contact" className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-bold uppercase tracking-wide transition-colors ${isActive('/contact')}`}>
                {t('contact')}
              </Link>
            </div>
          </div>

          {/* Right Icons */}
          <div className="hidden sm:ml-6 sm:flex sm:items-center space-x-4">
            
            {/* Theme Toggle */}
            <button 
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              aria-label="Toggle Dark Mode"
            >
              {theme === 'light' ? (
                <Moon className="w-5 h-5 text-gray-600" />
              ) : (
                <Sun className="w-5 h-5 text-yellow-400" />
              )}
            </button>

            {/* Language Toggle */}
            <div className="flex items-center space-x-1 bg-gray-100 dark:bg-gray-800 rounded-md px-3 py-1 cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700 transition">
              <Globe className="w-3 h-3 text-gray-500 dark:text-gray-400" />
              <button 
                onClick={() => setLanguage('EN')} 
                className={`text-xs font-bold ${language === 'EN' ? 'text-news-accent' : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'}`}
              >
                EN
              </button>
              <span className="text-gray-300 dark:text-gray-600">|</span>
              <button 
                onClick={() => setLanguage('HI')} 
                className={`text-xs font-bold ${language === 'HI' ? 'text-news-accent' : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'}`}
              >
                HI
              </button>
            </div>

            <button className="p-2 text-gray-400 hover:text-news-accent transition-colors">
              <Search className="h-5 w-5" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="-mr-2 flex items-center lg:hidden space-x-4">
            <button 
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
               {theme === 'light' ? (
                <Moon className="w-5 h-5 text-gray-600" />
              ) : (
                <Sun className="w-5 h-5 text-yellow-400" />
              )}
            </button>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 focus:outline-none"
            >
              {isOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden bg-white dark:bg-news-card border-b border-news-border dark:border-gray-700 shadow-lg">
          <div className="pt-2 pb-3 space-y-1">
            <Link to="/" onClick={() => setIsOpen(false)} className="block pl-3 pr-4 py-2 border-l-4 border-news-accent text-base font-medium text-news-ink dark:text-white bg-blue-50 dark:bg-blue-900/20">
              {t('home')}
            </Link>
            <Link to="/scores" onClick={() => setIsOpen(false)} className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-gray-300">
              {t('liveScore')}
            </Link>
            <Link to="/players" onClick={() => setIsOpen(false)} className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-gray-300">
              {t('players')}
            </Link>
            <Link to="/about" onClick={() => setIsOpen(false)} className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-gray-300">
              {t('about')}
            </Link>
            <Link to="/contact" onClick={() => setIsOpen(false)} className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-gray-300">
              {t('contact')}
            </Link>
            {/* Mobile Lang Switch */}
            <div className="px-3 py-2 flex items-center space-x-4">
              <button 
                onClick={() => { setLanguage('EN'); setIsOpen(false); }} 
                className={`text-sm font-bold ${language === 'EN' ? 'text-news-accent' : 'text-gray-500 dark:text-gray-400'}`}
              >
                English
              </button>
              <button 
                onClick={() => { setLanguage('HI'); setIsOpen(false); }} 
                className={`text-sm font-bold ${language === 'HI' ? 'text-news-accent' : 'text-gray-500 dark:text-gray-400'}`}
              >
                Hindi
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;