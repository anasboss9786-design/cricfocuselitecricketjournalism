import React from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import MatchHub from './pages/MatchHub';
import Scores from './pages/Scores';
import ArticlePage from './pages/ArticlePage';
import Players from './pages/Players';
import Contact from './pages/Contact';
import StaticPage from './components/StaticPage';
import { LanguageProvider } from './context/LanguageContext';
import { ThemeProvider } from './context/ThemeContext';

// ScrollToTop component to ensure page starts at top on navigation
const ScrollToTopHelper = () => {
  const { pathname } = useLocation();
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const App: React.FC = () => {
  return (
    <LanguageProvider>
      <ThemeProvider>
        <Router>
          <ScrollToTopHelper />
          <Layout>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/scores" element={<Scores />} />
              <Route path="/match/:id" element={<MatchHub />} />
              <Route path="/article/:id" element={<ArticlePage />} />
              
              <Route path="/players" element={<Players />} />
              <Route path="/contact" element={<Contact />} />
              
              {/* Static Pages managed via _CONTENT_MANAGER/static_pages.ts */}
              <Route path="/rankings" element={<StaticPage pageKey="rankings" />} />
              <Route path="/series" element={<StaticPage pageKey="series" />} />
              <Route path="/privacy" element={<StaticPage pageKey="privacy" />} />
              <Route path="/terms" element={<StaticPage pageKey="terms" />} />
              <Route path="/disclaimer" element={<StaticPage pageKey="disclaimer" />} />
              <Route path="/about" element={<StaticPage pageKey="about" />} />
            </Routes>
          </Layout>
        </Router>
      </ThemeProvider>
    </LanguageProvider>
  );
};

export default App;