import React from 'react';
import { useParams } from 'react-router-dom';
import { MOCK_ARTICLES_EN, MOCK_ARTICLES_HI } from '../services/mockData';
import { SITE_SETTINGS } from '../_CONTENT_MANAGER/settings';
import AdUnit from '../components/AdUnit';
import Sidebar from '../components/Sidebar';
import { Facebook, Twitter, Link as LinkIcon, Star, CheckCircle, XCircle } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

const ArticlePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { language, t } = useLanguage();
  
  // Choose correct dataset
  const dataset = language === 'HI' ? MOCK_ARTICLES_HI : MOCK_ARTICLES_EN;
  
  // Handle duplicate IDs from Home (e.g. 'a1-dup') by stripping suffix if exists
  const cleanId = id?.split('-dup')[0];
  
  const article = dataset.find(a => a.id === cleanId) || dataset[0];
  const isReview = !!article.rating;

  return (
    <article className="min-h-screen bg-news-paper pb-12">
      
      {/* Header Ad */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AdUnit code={SITE_SETTINGS.ads.headerAd} />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Main Content Column (8 Cols) */}
          <div className="lg:col-span-8">
            
            {/* Article Header */}
            <div className="mb-8">
              <div className="flex items-center space-x-2 mb-4">
                <span className="text-news-accent font-bold uppercase tracking-widest text-xs">{article.category}</span>
                <span className="h-px w-8 bg-news-accent"></span>
              </div>
              
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-news-ink leading-tight mb-6">
                {article.title}
              </h1>
              
              <div className="flex flex-wrap items-center text-gray-500 text-sm gap-x-4 gap-y-2 pb-6 border-b border-gray-200">
                 <span className="font-bold text-gray-900 uppercase tracking-wider">{article.author}</span>
                 <span>&bull;</span>
                 <span>{t('published')} {article.publishedAt}</span>
              </div>
            </div>

            {/* Main Image */}
            <div className="w-full mb-8">
              <img 
                src={article.imageUrl} 
                alt={article.title} 
                className="w-full aspect-video object-cover rounded-sm shadow-sm"
              />
              <p className="text-xs text-gray-400 mt-2 italic">Image source: Getty Images / Official Team Media</p>
            </div>

             {/* Excerpt */}
             <p className="text-xl font-serif leading-relaxed text-gray-700 mb-8 italic pl-4 border-l-4 border-news-accent">
                "{article.excerpt}"
              </p>

            {/* Review Score Box (if applicable) */}
            {isReview && (
              <div className="bg-white border border-gray-200 p-6 mb-8 rounded-sm shadow-sm">
                <div className="flex flex-col items-center mb-6">
                  <span className="text-sm uppercase tracking-widest font-bold text-gray-500 mb-2">Our Verdict</span>
                  <div className="text-5xl font-serif font-bold text-news-ink flex items-center">
                    {article.rating}<span className="text-2xl text-gray-400 font-sans font-normal ml-1">/10</span>
                  </div>
                  <div className="flex mt-2">
                     {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`w-5 h-5 ${i < Math.round((article.rating || 0)/2) ? 'text-news-accent fill-news-accent' : 'text-gray-300'}`} />
                     ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   {article.pros && (
                     <div>
                       <h4 className="font-bold uppercase tracking-wider text-xs mb-3 text-green-700 flex items-center">
                         <CheckCircle className="w-4 h-4 mr-1" /> The Good
                       </h4>
                       <ul className="space-y-2 text-sm text-gray-700">
                         {article.pros.map((pro, idx) => (
                           <li key={idx} className="flex items-start">
                             <span className="mr-2 text-gray-400">&bull;</span> {pro}
                           </li>
                         ))}
                       </ul>
                     </div>
                   )}
                   {article.cons && (
                     <div>
                       <h4 className="font-bold uppercase tracking-wider text-xs mb-3 text-red-700 flex items-center">
                         <XCircle className="w-4 h-4 mr-1" /> The Bad
                       </h4>
                       <ul className="space-y-2 text-sm text-gray-700">
                         {article.cons.map((con, idx) => (
                           <li key={idx} className="flex items-start">
                             <span className="mr-2 text-gray-400">&bull;</span> {con}
                           </li>
                         ))}
                       </ul>
                     </div>
                   )}
                </div>
              </div>
            )}

            {/* Content Body */}
            <div className="prose prose-lg prose-stone max-w-none font-serif text-gray-800">
               {article.content ? (
                 <div dangerouslySetInnerHTML={{ __html: article.content }} />
               ) : (
                 <p>Content not found.</p>
               )}
               
               {/* Inline Ad */}
               <AdUnit code={SITE_SETTINGS.ads.articleInlineAd} />
            </div>

            {/* Share Footer */}
            <div className="mt-12 pt-8 border-t border-gray-200">
               <div className="flex justify-between items-center">
                 <span className="font-bold text-sm uppercase text-gray-400">{t('shareStory')}</span>
                 <div className="flex space-x-4">
                   <button className="p-2 border border-gray-200 rounded-full hover:bg-gray-100"><Twitter className="w-4 h-4" /></button>
                   <button className="p-2 border border-gray-200 rounded-full hover:bg-gray-100"><Facebook className="w-4 h-4" /></button>
                   <button className="p-2 border border-gray-200 rounded-full hover:bg-gray-100"><LinkIcon className="w-4 h-4" /></button>
                 </div>
               </div>
            </div>

          </div>

          {/* Sidebar Column (4 Cols) */}
          <div className="lg:col-span-4">
             <div className="sticky top-24">
               <Sidebar />
             </div>
          </div>

        </div>
      </div>
    </article>
  );
};

export default ArticlePage;