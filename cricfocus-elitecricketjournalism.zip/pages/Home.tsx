import React, { useState } from 'react';
import ArticleCard from '../components/ArticleCard';
import { MOCK_ARTICLES_EN, MOCK_ARTICLES_HI, MOCK_VIDEOS } from '../services/mockData';
import { SITE_SETTINGS } from '../_CONTENT_MANAGER/settings';
import AdUnit from '../components/AdUnit';
import Sidebar from '../components/Sidebar';
import BreakingNews from '../components/BreakingNews';
import { ArrowRight, PlayCircle } from 'lucide-react';
import { Video } from '../types';
import { useLanguage } from '../context/LanguageContext';

// Helper Component for Inline Video Playback
const VideoPlayerCard: React.FC<{ video: Video }> = ({ video }) => {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <div className="group block bg-white dark:bg-news-card rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all">
      <div className="relative aspect-video bg-black overflow-hidden border-b border-gray-200 dark:border-gray-700">
        {isPlaying ? (
          <video 
            src={video.videoUrl} 
            controls 
            autoPlay
            playsInline
            className="w-full h-full object-contain bg-black"
            onEnded={() => setIsPlaying(false)}
          />
        ) : (
          <div 
            onClick={() => setIsPlaying(true)}
            className="w-full h-full relative cursor-pointer"
          >
            <img 
              src={video.thumbnailUrl} 
              alt={video.title} 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
            />
            {/* Dark Overlay */}
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
            
            {/* Play Button */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-14 h-14 bg-white/90 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                <PlayCircle className="w-7 h-7 text-news-accent ml-1" />
              </div>
            </div>

            {/* Duration Badge */}
            <span className="absolute bottom-2 right-2 bg-black/80 text-white text-[10px] px-2 py-0.5 rounded font-bold tracking-wider">
              {video.duration}
            </span>
          </div>
        )}
      </div>
      <div className="p-3">
        <h3 className={`font-bold text-lg leading-tight transition-colors ${isPlaying ? 'text-news-accent' : 'text-news-ink dark:text-white group-hover:text-news-accent'}`}>
          {video.title}
        </h3>
        <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">{video.publishedAt}</div>
      </div>
    </div>
  );
};

const Home: React.FC = () => {
  const { language, t } = useLanguage();
  
  // Select dataset based on language
  const articles = language === 'HI' ? MOCK_ARTICLES_HI : MOCK_ARTICLES_EN;

  const featuredArticle = articles[0];
  const standardArticles = articles.slice(1);

  return (
    <div className="min-h-screen bg-news-paper dark:bg-news-dark transition-colors duration-300">
      
      {/* Breaking News Ticker */}
      <BreakingNews />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Header Ad Slot */}
        <AdUnit code={SITE_SETTINGS.ads.headerAd} />

        {/* Hero Section */}
        <ArticleCard article={featuredArticle} variant="featured" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Main Feed - Left Column */}
          <div className="lg:col-span-8">
            <div className="flex items-center justify-between mb-6 pb-2 border-b-2 border-black dark:border-gray-700">
              <h2 className="text-2xl font-serif font-bold text-news-ink dark:text-white">{t('latestAnalysis')}</h2>
              <button className="text-sm font-medium text-news-accent flex items-center hover:underline">
                {t('viewAll')} <ArrowRight className="w-4 h-4 ml-1" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {standardArticles.map(article => (
                <ArticleCard key={article.id} article={article} />
              ))}
               {/* Duplicate for visual fullness if article count is low */}
              {standardArticles.length < 4 && standardArticles.map((article, idx) => (
                <ArticleCard key={`${article.id}-dup-${idx}`} article={{...article, id: `${article.id}-dup`}} />
              ))}
            </div>
          </div>

          {/* Sidebar - Right Column */}
          <div className="lg:col-span-4">
            <Sidebar />
          </div>
        </div>

        {/* Video Section */}
        {MOCK_VIDEOS.length > 0 && (
          <div className="mt-16 pt-12 border-t border-gray-200 dark:border-gray-800">
             <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-serif font-bold text-news-ink dark:text-white flex items-center">
                  <PlayCircle className="w-6 h-6 mr-2 text-news-accent" />
                  {t('featuredVideos')}
                </h2>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {MOCK_VIDEOS.map(video => (
                   <VideoPlayerCard key={video.id} video={video} />
                ))}
             </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default Home;