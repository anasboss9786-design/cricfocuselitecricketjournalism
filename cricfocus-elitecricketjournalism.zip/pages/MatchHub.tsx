import React, { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { MOCK_MATCHES, MOCK_COMMENTARY } from '../services/mockData';
import { Match, MatchStatus, Commentary, MatchWeather } from '../types';
import { Share2, Sun, Cloud, CloudRain, Wind, MapPin, AlignLeft, Flag, CircleDot } from 'lucide-react';

const EVENTS = [
  { type: '0', prob: 0.35, text: ['Defended solidly back to the bowler.', 'Left alone outside off.', 'Beaten! Lovely bowling.', 'Straight to the fielder at cover.'] },
  { type: '1', prob: 0.3, text: ['Pushed into the gap for a single.', 'Quick single taken.', 'Edged but safe, they get one.', 'Tucked off the pads for a run.'] },
  { type: '2', prob: 0.1, text: ['Driven through the covers, cuts it off for two.', 'Good running, they push hard for the second.', 'Worked away to deep square leg.'] },
  { type: '4', prob: 0.1, text: ['FOUR! Glorious drive through extra cover.', 'FOUR! Short and pulled away disdainfully.', 'FOUR! Edged and flies past slip!', 'FOUR! Swept away to the fine leg boundary.'] },
  { type: '6', prob: 0.05, text: ['SIX! That is huge! Out of the stadium.', 'SIX! Down the ground and into the sightscreen.', 'SIX! Picked the length early and dispatched it.'] },
  { type: 'W', prob: 0.05, text: ['OUT! Clean bowled! The middle stump is uprooted.', 'OUT! Edged and taken at first slip!', 'OUT! LBW! Plumb in front.', 'OUT! Caught in the deep. He tried to go big but mistimed it.'] },
];

const MatchHub: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const initialMatch = MOCK_MATCHES.find(m => m.id === id) || MOCK_MATCHES[0];
  
  const [match, setMatch] = useState<Match>(initialMatch);
  const [activeTab, setActiveTab] = useState<'scorecard' | 'commentary' | 'info'>('commentary');
  const [commentary, setCommentary] = useState<Commentary[]>(MOCK_COMMENTARY);
  const [weather, setWeather] = useState<MatchWeather | undefined>(initialMatch.weather);

  // Simulation Logic
  useEffect(() => {
    if (match.status !== MatchStatus.LIVE) return;

    const interval = setInterval(() => {
      // 1. Pick an event based on probability
      const rand = Math.random();
      let cumulativeProb = 0;
      let selectedEvent = EVENTS[0];
      
      for (const event of EVENTS) {
        cumulativeProb += event.prob;
        if (rand <= cumulativeProb) {
          selectedEvent = event;
          break;
        }
      }

      // 2. Update Scores
      setMatch(prev => {
        if (!prev.scoreHome) return prev;
        
        let runsToAdd = 0;
        let wicketToAdd = 0;

        if (selectedEvent.type === 'W') {
          wicketToAdd = 1;
        } else {
          runsToAdd = parseInt(selectedEvent.type);
        }

        // Calculate new overs
        let newBalls = Math.round((prev.scoreHome.overs % 1) * 10) + 1;
        let newOvers = Math.floor(prev.scoreHome.overs);
        
        if (newBalls === 6) {
          newOvers += 1;
          newBalls = 0;
        }

        const updatedScore = {
           ...prev.scoreHome,
           runs: prev.scoreHome.runs + runsToAdd,
           wickets: prev.scoreHome.wickets + wicketToAdd,
           overs: parseFloat(`${newOvers}.${newBalls}`)
        };

        // If 10 wickets, stop simulation (in a real app) or just reset/loop for demo
        if (updatedScore.wickets >= 10) {
           // For demo, we just keep them at 9 down or reset
           updatedScore.wickets = 9;
        }

        return {
          ...prev,
          scoreHome: updatedScore
        };
      });

      // 3. Generate Commentary
      const newComm: Commentary = {
        id: Date.now().toString(),
        ball: match.scoreHome.overs,
        runs: selectedEvent.type,
        isWicket: selectedEvent.type === 'W',
        isBoundary: selectedEvent.type === '4' || selectedEvent.type === '6',
        bowler: match.currentBowler || 'Bowler',
        batsman: match.currentBatter || 'Batter',
        text: selectedEvent.text[Math.floor(Math.random() * selectedEvent.text.length)],
        timestamp: 'Just now'
      };
      
      setCommentary(prev => [newComm, ...prev.slice(0, 19)]); // Keep last 20

      // 4. Occasional Weather Update (10% chance)
      if (Math.random() > 0.90 && weather) {
        const conditions: Array<MatchWeather['condition']> = ['Sunny', 'Cloudy', 'Overcast', 'Clear'];
        const newCondition = conditions[Math.floor(Math.random() * conditions.length)];
        setWeather(prev => prev ? ({ ...prev, condition: newCondition }) : undefined);
      }

    }, 2500); // Fast updates for demo

    return () => clearInterval(interval);
  }, [match.status, match.scoreHome, weather, match.currentBowler, match.currentBatter]);

  const getWeatherIcon = (cond?: string) => {
    switch (cond) {
      case 'Rain': return <CloudRain className="w-5 h-5" />;
      case 'Cloudy': return <Cloud className="w-5 h-5" />;
      case 'Overcast': return <Cloud className="w-5 h-5 text-gray-400" />;
      default: return <Sun className="w-5 h-5 text-yellow-500" />;
    }
  };

  return (
    <div className="bg-news-paper min-h-screen pb-12">
      {/* Match Header */}
      <div className="bg-news-ink text-white pt-8 pb-12 relative overflow-hidden">
         {/* Texture overlay for header */}
         <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]"></div>
         
         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-2">
              <span className="text-gray-400 text-sm font-medium tracking-wider uppercase flex items-center">
                <MapPin className="w-3 h-3 mr-1" /> {match.venue}
              </span>
              
              {weather && (
                <div className="flex items-center space-x-2 bg-white/10 px-3 py-1 rounded-full text-xs font-bold">
                  {getWeatherIcon(weather.condition)}
                  <span>{weather.temp} &bull; {weather.condition}</span>
                  <span className="text-gray-400 ml-1 hidden sm:inline">Humidity: {weather.humidity}</span>
                </div>
              )}
            </div>

            <div className="flex flex-col md:flex-row items-center justify-between gap-8">
              {/* Home Team */}
              <div className="flex items-center space-x-4 text-left w-full md:w-auto justify-center md:justify-start">
                <img src={match.teamHome.flag} alt={match.teamHome.name} className="w-16 h-10 shadow-sm rounded-sm object-cover" />
                <div>
                  <h1 className="text-4xl font-serif font-bold">{match.teamHome.shortName}</h1>
                  <div className="text-2xl font-mono text-news-accent mt-1">
                    {match.scoreHome?.runs}/{match.scoreHome?.wickets} <span className="text-lg text-gray-500">({match.scoreHome?.overs})</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-col items-center">
                 <div className="text-news-accent font-bold uppercase tracking-widest text-xs mb-2 flex items-center">
                    <CircleDot className="w-3 h-3 mr-2 animate-pulse" />
                    {match.status === MatchStatus.LIVE ? 'Live Update' : 'Result'}
                 </div>
                 <div className="text-gray-400 text-sm font-medium bg-white/5 px-4 py-1 rounded-full text-center">
                    {match.summary}
                 </div>
              </div>

              {/* Away Team */}
              <div className="flex items-center space-x-4 text-right flex-row-reverse md:flex-row w-full md:w-auto justify-center md:justify-end">
                <div className="md:text-right">
                  <h1 className="text-4xl font-serif font-bold">{match.teamAway.shortName}</h1>
                   <div className="text-2xl font-mono text-gray-300 mt-1">
                    {match.scoreAway?.runs || '0'}/{match.scoreAway?.wickets || '0'} <span className="text-lg text-gray-500">({match.scoreAway?.overs || '0.0'})</span>
                  </div>
                </div>
                <img src={match.teamAway.flag} alt={match.teamAway.name} className="w-16 h-10 shadow-sm rounded-sm object-cover md:ml-4 ml-0 mr-4 md:mr-0" />
              </div>
            </div>
            
            {/* Toss Info */}
            <div className="mt-8 text-center border-t border-white/10 pt-4">
              <p className="text-white font-bold text-sm flex items-center justify-center">
                <CircleDot className="w-3 h-3 text-news-accent mr-2" />
                {match.toss || 'Toss yet to happen.'}
              </p>
            </div>
         </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-gray-200 bg-white sticky top-16 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="-mb-px flex space-x-8" aria-label="Tabs">
            {[
              { id: 'commentary', label: 'Commentary' },
              { id: 'scorecard', label: 'Scorecard' },
              { id: 'info', label: 'Match Info' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`
                  whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm uppercase tracking-wider
                  ${activeTab === tab.id 
                    ? 'border-news-accent text-news-accent' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
                `}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left/Main Column */}
          <div className="lg:col-span-8">
            
            {activeTab === 'commentary' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between mb-4 bg-white p-4 rounded-sm border border-gray-200 shadow-sm">
                  <h3 className="font-serif text-lg font-bold">Ball by Ball Commentary</h3>
                  <div className="flex space-x-2">
                     <span className="text-xs font-mono bg-red-50 text-red-600 px-2 py-1 rounded border border-red-100">Live</span>
                  </div>
                </div>

                <div className="space-y-0 relative border-l-2 border-gray-200 ml-4">
                  {commentary.map((comm, index) => (
                    <div key={comm.id} className={`relative pl-8 pb-8 group ${index === 0 ? 'animate-pulse-slow' : ''}`}>
                      {/* Timeline Dot */}
                      <div className={`
                        absolute -left-[11px] top-0 w-[20px] h-[20px] rounded-full border-2 border-white
                        flex items-center justify-center text-[10px] font-bold shadow-sm z-10
                        ${comm.isWicket ? 'bg-red-600 text-white' : comm.isBoundary ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-600 border-gray-300'}
                      `}>
                        {comm.isWicket ? 'W' : comm.runs}
                      </div>

                      <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between mb-1">
                        <div className="font-mono text-base font-bold text-gray-900">
                          {typeof comm.ball === 'number' ? comm.ball.toFixed(1) : comm.ball} <span className="text-gray-400 font-sans font-normal mx-2">&bull;</span> {comm.bowler} to {comm.batsman}
                        </div>
                        <div className="text-xs text-gray-400 font-medium mt-1 sm:mt-0 uppercase tracking-wide">{comm.timestamp}</div>
                      </div>
                      
                      <p className={`text-gray-800 leading-relaxed text-sm ${comm.isWicket || comm.isBoundary ? 'font-bold' : ''}`}>
                        {comm.text}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'scorecard' && (
              <div className="bg-white border border-gray-200 p-8 text-center rounded-sm shadow-sm">
                <div className="animate-pulse flex flex-col items-center justify-center py-12">
                   <AlignLeft className="w-12 h-12 text-gray-300 mb-4" />
                   <h3 className="text-xl font-bold text-gray-400">Full Scorecard Loading...</h3>
                   <p className="text-gray-400 mt-2">Real-time data synchronization in progress.</p>
                </div>
              </div>
            )}

            {activeTab === 'info' && (
              <div className="space-y-6">
                 {/* Match Info Card */}
                 <div className="bg-white border border-gray-200 rounded-sm shadow-sm overflow-hidden">
                    <div className="bg-gray-50 px-6 py-3 border-b border-gray-200 font-bold uppercase text-xs tracking-widest text-gray-500">
                      Match Information
                    </div>
                    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                       <div>
                          <h4 className="text-sm font-bold text-news-ink mb-1">Series</h4>
                          <p className="text-gray-600 text-sm">International Tour 2025</p>
                       </div>
                       <div>
                          <h4 className="text-sm font-bold text-news-ink mb-1">Match Date</h4>
                          <p className="text-gray-600 text-sm">{new Date(match.startTime).toLocaleDateString()} {new Date(match.startTime).toLocaleTimeString()}</p>
                       </div>
                       <div>
                          <h4 className="text-sm font-bold text-news-ink mb-1">Venue</h4>
                          <p className="text-gray-600 text-sm">{match.venue}</p>
                       </div>
                       <div>
                          <h4 className="text-sm font-bold text-news-ink mb-1">Umpires</h4>
                          <p className="text-gray-600 text-sm">Richard Kettleborough, Nitin Menon</p>
                       </div>
                    </div>
                 </div>

                 {/* Pitch Report Card */}
                 <div className="bg-white border border-gray-200 rounded-sm shadow-sm overflow-hidden">
                    <div className="bg-gray-50 px-6 py-3 border-b border-gray-200 font-bold uppercase text-xs tracking-widest text-gray-500 flex items-center">
                      Pitch Report <span className="ml-2 bg-green-100 text-green-800 text-[10px] px-2 py-0.5 rounded">Official</span>
                    </div>
                    <div className="p-6">
                       <p className="text-gray-700 leading-relaxed font-serif italic text-lg">
                         "{match.pitchReport || 'Pitch report will be updated shortly.'}"
                       </p>
                    </div>
                 </div>

                 {/* Weather Card */}
                 {weather && (
                  <div className="bg-white border border-gray-200 rounded-sm shadow-sm overflow-hidden">
                      <div className="bg-gray-50 px-6 py-3 border-b border-gray-200 font-bold uppercase text-xs tracking-widest text-gray-500">
                        Live Weather Conditions
                      </div>
                      <div className="p-6 flex items-center justify-between">
                         <div className="flex items-center">
                            <div className="mr-4 text-news-accent">
                               {getWeatherIcon(weather.condition)}
                            </div>
                            <div>
                               <div className="text-3xl font-bold text-news-ink">{weather.temp}</div>
                               <div className="text-gray-500 font-medium">{weather.condition}</div>
                            </div>
                         </div>
                         <div className="text-right space-y-1">
                            <div className="text-sm text-gray-600"><span className="font-bold">Humidity:</span> {weather.humidity}</div>
                            <div className="text-sm text-gray-600"><span className="font-bold">Wind:</span> 12 km/h NE</div>
                         </div>
                      </div>
                  </div>
                 )}
              </div>
            )}

          </div>

          {/* Right Sidebar - Stats */}
          <div className="lg:col-span-4 space-y-8">
            
            {/* Live Batter Widget */}
            <div className="bg-white border border-gray-200 p-6 rounded-sm shadow-sm">
              <h4 className="text-xs font-bold uppercase tracking-widest text-gray-500 mb-4 flex items-center">
                 <CircleDot className="w-2 h-2 text-red-500 mr-2 animate-pulse" /> On Strike
              </h4>
              <div className="flex items-center justify-between mb-4">
                 <div className="flex items-center space-x-3">
                   <div className="w-12 h-12 rounded-full overflow-hidden border border-gray-200 bg-gray-100">
                     <img 
                       src="https://images.unsplash.com/photo-1624526267942-ab0ff8a3e972?q=80&w=200&h=200&auto=format&fit=crop" 
                       alt="Batter" 
                       className="w-full h-full object-cover"
                     />
                   </div>
                   <div>
                     <div className="font-bold text-news-ink text-sm">{match.currentBatter || 'Batter'}</div>
                     <div className="text-[10px] text-gray-500 font-bold uppercase">Right Hand Bat</div>
                   </div>
                 </div>
                 <div className="text-right">
                   <div className="text-2xl font-mono font-bold">42*</div>
                   <div className="text-xs text-gray-500">off 31 balls</div>
                 </div>
              </div>
               <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden">
                 <div className="bg-news-ink h-full" style={{ width: '45%' }}></div>
               </div>
               <div className="flex justify-between text-[10px] text-gray-400 mt-1">
                 <span>SR: 135.4</span>
                 <span>Proj: {Math.round(match.scoreHome.runs * 1.2)}</span>
               </div>
            </div>

            {/* Current Bowler Widget */}
            <div className="bg-white border border-gray-200 p-6 rounded-sm shadow-sm">
              <h4 className="text-xs font-bold uppercase tracking-widest text-gray-500 mb-4">Current Bowler</h4>
              <div className="flex items-center justify-between">
                 <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-500">
                       {match.currentBowler?.charAt(0) || 'B'}
                    </div>
                    <div>
                       <div className="font-bold text-sm">{match.currentBowler || 'Bowler'}</div>
                       <div className="text-xs text-gray-500">Right-arm Fast</div>
                    </div>
                 </div>
                 <div className="text-right text-sm font-mono">
                    <span className="font-bold">2/28</span> <span className="text-gray-400">(3.2)</span>
                 </div>
              </div>
            </div>

            {/* Key Stats */}
            <div className="bg-news-paper">
              <h3 className="font-serif text-lg font-bold mb-4 border-b border-gray-200 pb-2">Match Stats</h3>
              <dl className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-white border border-gray-100">
                  <dt className="text-xs text-gray-500 uppercase">Run Rate</dt>
                  <dd className="text-lg font-mono font-bold">{(match.scoreHome.runs / (match.scoreHome.overs || 1)).toFixed(2)}</dd>
                </div>
                <div className="p-3 bg-white border border-gray-100">
                  <dt className="text-xs text-gray-500 uppercase">Req. Rate</dt>
                  <dd className="text-lg font-mono font-bold text-news-accent">--</dd>
                </div>
                <div className="p-3 bg-white border border-gray-100">
                  <dt className="text-xs text-gray-500 uppercase">Win Prob</dt>
                  <dd className="text-lg font-mono font-bold text-green-700">
                     {match.scoreHome.runs > 200 ? `${match.teamHome.shortName} 75%` : `${match.teamAway.shortName} 60%`}
                  </dd>
                </div>
              </dl>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default MatchHub;