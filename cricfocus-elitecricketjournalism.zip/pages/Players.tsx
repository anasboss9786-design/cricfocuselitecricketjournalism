import React from 'react';
import AdUnit from '../components/AdUnit';
import { SITE_SETTINGS } from '../_CONTENT_MANAGER/settings';

// Realistic stats updated for early 2025 context with Avatar Images
const PLAYERS_MOCK = [
  { 
    id: 1, 
    name: 'Virat Kohli', 
    country: 'India', 
    role: 'Batter', 
    matches: 538, 
    runs: 27129, 
    avg: 53.19, 
    sr: 79.82,
    avatar: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?q=80&w=200&auto=format&fit=crop' // Generic athletic portrait
  },
  { 
    id: 2, 
    name: 'Rohit Sharma', 
    country: 'India', 
    role: 'Batter', 
    matches: 486, 
    runs: 19276, 
    avg: 43.12, 
    sr: 91.58,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&auto=format&fit=crop'
  },
  { 
    id: 3, 
    name: 'Steve Smith', 
    country: 'Australia', 
    role: 'Batter', 
    matches: 339, 
    runs: 16426, 
    avg: 48.02, 
    sr: 68.10,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop'
  },
  { 
    id: 4, 
    name: 'Jasprit Bumrah', 
    country: 'India', 
    role: 'Bowler', 
    matches: 198, 
    wickets: 412, 
    avg: 21.40, 
    eco: 4.59,
    avatar: 'https://images.unsplash.com/photo-1480455624313-e29b44bbfde1?q=80&w=200&auto=format&fit=crop'
  },
  { 
    id: 5, 
    name: 'Babar Azam', 
    country: 'Pakistan', 
    role: 'Batter', 
    matches: 302, 
    runs: 13867, 
    avg: 47.32, 
    sr: 83.75,
    avatar: 'https://images.unsplash.com/photo-1504257432389-52343af06ae3?q=80&w=200&auto=format&fit=crop'
  },
  { 
    id: 6, 
    name: 'Joe Root', 
    country: 'England', 
    role: 'Batter', 
    matches: 352, 
    runs: 19845, 
    avg: 49.15, 
    sr: 64.20,
    avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=200&auto=format&fit=crop'
  },
  { 
    id: 7, 
    name: 'Pat Cummins', 
    country: 'Australia', 
    role: 'Bowler', 
    matches: 205, 
    wickets: 478, 
    avg: 22.10, 
    eco: 4.10,
    avatar: 'https://images.unsplash.com/photo-1542909168-82c3e7fdca5c?q=80&w=200&auto=format&fit=crop'
  },
  { 
    id: 8, 
    name: 'Kane Williamson', 
    country: 'New Zealand', 
    role: 'Batter', 
    matches: 360, 
    runs: 18200, 
    avg: 48.50, 
    sr: 70.10,
    avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?q=80&w=200&auto=format&fit=crop'
  },
];

const Players: React.FC = () => {
  return (
    <div className="bg-news-paper min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <AdUnit code={SITE_SETTINGS.ads.headerAd} />

        <h1 className="text-4xl font-serif font-bold text-news-ink mb-8 border-b-2 border-black pb-4">
          Player Statistics Database
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Table */}
          <div className="lg:col-span-2">
            <div className="bg-white border border-gray-200 shadow-sm rounded-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-news-ink text-white text-xs uppercase tracking-wider">
                    <tr>
                      <th className="p-4">Profile</th>
                      <th className="p-4">Player</th>
                      <th className="p-4">Team</th>
                      <th className="p-4">Role</th>
                      <th className="p-4">Mat</th>
                      <th className="p-4">Intl Runs</th>
                      <th className="p-4">Avg</th>
                      <th className="p-4">SR/Eco</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 text-sm">
                    {PLAYERS_MOCK.map((player) => (
                      <tr key={player.id} className="hover:bg-gray-50 transition-colors group cursor-pointer">
                        <td className="p-4">
                          <img 
                            src={player.avatar} 
                            alt={player.name} 
                            className="w-10 h-10 rounded-full object-cover border-2 border-gray-100 group-hover:border-news-accent transition-colors"
                          />
                        </td>
                        <td className="p-4 font-bold text-news-ink group-hover:text-news-accent transition-colors">{player.name}</td>
                        <td className="p-4 text-gray-600">{player.country}</td>
                        <td className="p-4 text-xs font-bold uppercase text-gray-400">{player.role}</td>
                        <td className="p-4 font-mono">{player.matches}</td>
                        <td className="p-4 font-mono font-bold">{player.runs || player.wickets}</td>
                        <td className="p-4 font-mono">{player.avg}</td>
                        <td className="p-4 font-mono">{player.sr || player.eco}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Featured Player Bio */}
            <div className="mt-12">
              <h2 className="text-2xl font-serif font-bold mb-4">Featured Biography: Virat Kohli</h2>
              <div className="bg-white p-8 border border-gray-200 flex flex-col md:flex-row gap-8">
                <div className="w-full md:w-1/3">
                  <img src="https://images.unsplash.com/photo-1506126613408-eca07ce68773?q=80&w=500&auto=format&fit=crop" className="w-full rounded-sm shadow-md" alt="Virat Kohli" />
                </div>
                <div className="w-full md:w-2/3">
                  <h3 className="text-xl font-bold text-news-accent mb-2">The Run Machine</h3>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Virat Kohli (born 5 November 1988) is an Indian international cricketer. He is widely regarded as one of the greatest batsmen in the history of the sport. Kohli plays for Royal Challengers Bangalore in the IPL and Delhi in domestic cricket.
                  </p>
                  <p className="text-gray-700 leading-relaxed">
                     With over 27,000 international runs and 80 centuries, Kohli's consistency across formats is unmatched. He led India to historic Test series wins in Australia and has been the recipient of the ICC Cricketer of the Decade award.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
             <div className="bg-stone-100 p-6 border border-gray-200 mb-8 sticky top-24">
               <h3 className="font-bold uppercase tracking-widest text-xs mb-4 text-gray-500">Search Player</h3>
               <input type="text" placeholder="Enter player name..." className="w-full p-3 border border-gray-300 rounded-sm mb-2 focus:outline-none focus:border-news-accent" />
               <button className="w-full bg-news-ink text-white py-3 font-bold text-sm uppercase hover:bg-news-accent transition-colors">Search Database</button>
             </div>
             <AdUnit code={SITE_SETTINGS.ads.sidebarAd} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Players;