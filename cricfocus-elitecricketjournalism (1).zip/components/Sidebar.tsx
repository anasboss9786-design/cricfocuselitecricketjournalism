import React, { useState } from 'react';
import AdUnit from './AdUnit';
import { SITE_SETTINGS } from '../_CONTENT_MANAGER/settings';
import { MOCK_ARTICLES_EN, MOCK_ARTICLES_HI, MOCK_MATCHES } from '../services/mockData';
import ArticleCard from './ArticleCard';
import { Calendar, Instagram } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const Sidebar: React.FC = () => {
  const { ads, sidebar } = SITE_SETTINGS;
  const navigate = useNavigate();
  const [pollVoted, setPollVoted] = useState(false);
  const { language, t } = useLanguage();

  // Filter upcoming matches for the sidebar
  const upcomingMatches = MOCK_MATCHES.filter(m => m.status === 'UPCOMING' || m.status === 'LIVE').slice(0, 3);
  
  // Get trending/short articles based on language
  const articles = language === 'HI' ? MOCK_ARTICLES_HI : MOCK_ARTICLES_EN;
  const trendingArticles = articles.slice(2, 5);

  return (
    <div className="space-y-12">
      
      {/* 1. Sidebar Ad */}
      <AdUnit code={ads.sidebarAd} />

      {/* 2. Social Follow Widget (Highlight User's Instagram) */}
      <div className="bg-white dark:bg-news-card border border-gray-200 dark:border-gray-700 p-6 rounded-lg shadow-sm">
         <h3 className="font-bold uppercase tracking-widest text-xs text-gray-500 dark:text-gray-400 mb-4">{t('followUs')}</h3>
         <div className="flex flex-col space-y-3">
            {SITE_SETTINGS.socials.instagram && (
              <a 
                href={SITE_SETTINGS.socials.instagram} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="flex items-center justify-center w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-sm rounded-md hover:shadow-lg transition-all transform hover:-translate-y-0.5"
              >
                 <Instagram className="w-5 h-5 mr-2" />
                 Follow on Instagram
              </a>
            )}
         </div>
      </div>

      {/* 3. Poll Widget */}
      {sidebar.showPoll && (
        <div className="bg-white dark:bg-news-card border border-gray-200 dark:border-gray-700 p-6 rounded-lg shadow-sm transition-colors">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold uppercase tracking-widest text-xs text-news-accent">Fan Poll</h3>
            <span className="text-[10px] bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded-full font-bold animate-pulse">Live</span>
          </div>
          <h4 className="font-serif font-bold text-lg mb-4 text-news-ink dark:text-white">{SITE_SETTINGS.sidebar.poll.question}</h4>
          
          {!pollVoted ? (
            <div className="space-y-2">
              {SITE_SETTINGS.sidebar.poll.options.map((option, idx) => (
                <button 
                  key={idx}
                  onClick={() => setPollVoted(true)}
                  className="w-full text-left px-4 py-3 bg-gray-50 dark:bg-gray-800 hover:bg-news-paper dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-md text-sm font-medium transition-colors hover:border-news-accent dark:text-gray-200"
                >
                  {option}
                </button>
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              {SITE_SETTINGS.sidebar.poll.options.map((option, idx) => {
                const percent = Math.floor(Math.random() * 80); // Fake percentage for demo
                return (
                  <div key={idx} className="relative">
                    <div className="flex justify-between text-xs mb-1 text-gray-700 dark:text-gray-300">
                      <span className="font-bold">{option}</span>
                      <span>{percent}%</span>
                    </div>
                    <div className="w-full bg-gray-100 dark:bg-gray-700 h-2 rounded-full overflow-hidden">
                      <div className="bg-news-accent h-full" style={{ width: `${percent}%` }}></div>
                    </div>
                  </div>
                )
              })}
              <p className="text-xs text-center text-gray-400 mt-4">Thank you for voting!</p>
            </div>
          )}
        </div>
      )}

      {/* 4. Upcoming Matches Widget */}
      {sidebar.showMatchSchedule && upcomingMatches.length > 0 && (
        <div className="bg-white dark:bg-news-card border border-gray-200 dark:border-gray-700 shadow-sm rounded-lg overflow-hidden transition-colors">
           <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center bg-gray-50 dark:bg-white/5">
             <h3 className="font-bold uppercase tracking-widest text-xs text-gray-600 dark:text-gray-300">Match Schedule</h3>
             <Calendar className="w-3 h-3 text-gray-400" />
           </div>
           <div className="divide-y divide-gray-200 dark:divide-gray-700">
             {upcomingMatches.map(match => (
               <div 
                 key={match.id} 
                 onClick={() => navigate(`/match/${match.id}`)}
                 className="p-4 hover:bg-blue-50 dark:hover:bg-blue-900/20 cursor-pointer transition-colors group"
               >
                 <div className="text-[10px] text-news-accent font-bold uppercase mb-1">{match.format}</div>
                 <div className="flex justify-between items-center mb-1">
                   <span className="font-bold text-sm text-gray-900 dark:text-white">{match.teamHome.shortName} vs {match.teamAway.shortName}</span>
                 </div>
                 <div className="text-xs text-gray-500 dark:text-gray-400 group-hover:text-news-ink dark:group-hover:text-gray-200 transition-colors">
                   {match.venue.split(',')[0]}
                 </div>
               </div>
             ))}
           </div>
           <button 
            onClick={() => navigate('/scores')}
            className="w-full py-3 text-center text-xs font-bold uppercase tracking-wider text-news-accent hover:bg-gray-50 dark:hover:bg-white/5 transition-colors border-t border-gray-200 dark:border-gray-700"
           >
             {t('viewAll')}
           </button>
        </div>
      )}

      {/* 5. Editor's Choice / Trending */}
      <div>
        <div className="mb-4 pb-1 border-b border-gray-300 dark:border-gray-700 flex justify-between items-center">
          <h3 className="font-sans text-xs font-bold uppercase tracking-widest text-gray-500 dark:text-gray-400">{t('editorsChoice')}</h3>
        </div>
        <div className="space-y-2">
            {trendingArticles.map((article) => (
            <ArticleCard key={`side-${article.id}`} article={article} variant="compact" />
          ))}
        </div>
      </div>

      {/* 6. Newsletter */}
      {sidebar.showNewsletter && (
        <div className="bg-news-ink dark:bg-black text-news-paper p-6 text-center rounded-lg relative overflow-hidden shadow-lg">
           <div className="relative z-10">
             <h4 className="font-serif text-xl font-bold mb-2 text-white">{t('newsletterTitle')}</h4>
             <p className="text-gray-400 text-sm mb-4">{t('newsletterDesc')}</p>
             <input type="email" placeholder="Your email address" className="w-full bg-white/10 border border-white/20 p-2 text-sm text-white placeholder-gray-500 mb-2 focus:outline-none focus:border-news-accent focus:ring-1 focus:ring-news-accent rounded-sm" />
             <button className="w-full bg-news-accent text-white py-2 text-xs font-bold uppercase tracking-wider hover:bg-blue-600 transition-colors rounded-sm">
               {t('subscribe')}
             </button>
           </div>
        </div>
      )}

    </div>
  );
};

export default Sidebar;