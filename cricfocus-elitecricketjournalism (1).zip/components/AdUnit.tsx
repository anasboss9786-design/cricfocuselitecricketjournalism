import React from 'react';

interface AdUnitProps {
  code: string;
  label?: boolean;
}

const AdUnit: React.FC<AdUnitProps> = ({ code, label = true }) => {
  if (!code || code.trim() === '') return null;

  return (
    <div className="w-full my-8 flex flex-col items-center">
      {label && <span className="text-[10px] uppercase text-gray-400 tracking-widest mb-2">Advertisement</span>}
      <div 
        className="w-full flex justify-center overflow-hidden"
        dangerouslySetInnerHTML={{ __html: code }}
      />
    </div>
  );
};

export default AdUnit;
