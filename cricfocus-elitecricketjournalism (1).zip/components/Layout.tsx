import React from 'react';
import Navbar from './Navbar';
import ScoreStrip from './ScoreStrip';
import { MOCK_MATCHES } from '../services/mockData';
import { SITE_SETTINGS } from '../_CONTENT_MANAGER/settings';
import { Instagram, Twitter, Facebook, Youtube, Aperture } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { socials } = SITE_SETTINGS;
  const { t } = useLanguage();

  return (
    <div className="min-h-screen flex flex-col font-sans bg-news-paper dark:bg-news-dark transition-colors duration-300">
      <div className="sticky top-0 z-50 shadow-lg">
        <ScoreStrip matches={MOCK_MATCHES} />
        <Navbar />
      </div>
      <main className="flex-grow">
        {children}
      </main>
      <footer className="bg-news-ink dark:bg-black text-white pt-16 pb-8 mt-auto border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-1">
             <h2 className="font-sans font-black text-2xl italic mb-6 flex items-center">
               <Aperture className="w-6 h-6 text-news-accent mr-2" />
               Cric<span className="text-news-accent">Focus</span>
             </h2>
             <p className="text-gray-400 text-sm leading-relaxed mb-6">
               {t('footerDesc')}
             </p>
             <div className="flex space-x-4 text-gray-400">
                {socials.twitter && <a href={socials.twitter} target="_blank" rel="noopener noreferrer" className="hover:text-news-accent transition"><Twitter className="w-5 h-5" /></a>}
                {socials.facebook && <a href={socials.facebook} target="_blank" rel="noopener noreferrer" className="hover:text-news-accent transition"><Facebook className="w-5 h-5" /></a>}
                {socials.instagram && <a href={socials.instagram} target="_blank" rel="noopener noreferrer" className="hover:text-news-accent transition"><Instagram className="w-5 h-5" /></a>}
                {socials.youtube && <a href={socials.youtube} target="_blank" rel="noopener noreferrer" className="hover:text-news-accent transition"><Youtube className="w-5 h-5" /></a>}
             </div>
          </div>
          
          <div>
            <h4 className="font-bold uppercase tracking-widest text-xs mb-6 text-gray-500">{t('quickLinks')}</h4>
            <ul className="space-y-3 text-sm text-gray-300">
              <li><Link to="/" className="hover:text-news-accent transition-colors">{t('home')}</Link></li>
              <li><Link to="/scores" className="hover:text-news-accent transition-colors">{t('liveScore')}</Link></li>
              <li><Link to="/series" className="hover:text-news-accent transition-colors">Series Schedule</Link></li>
              <li><Link to="/players" className="hover:text-news-accent transition-colors">{t('players')}</Link></li>
              <li><Link to="/about" className="hover:text-news-accent transition-colors">{t('about')}</Link></li>
              <li><Link to="/contact" className="hover:text-news-accent transition-colors">{t('contact')}</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold uppercase tracking-widest text-xs mb-6 text-gray-500">{t('legal')}</h4>
            <ul className="space-y-3 text-sm text-gray-300">
              <li><Link to="/privacy" className="hover:text-news-accent transition-colors">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-news-accent transition-colors">Terms & Conditions</Link></li>
              <li><Link to="/disclaimer" className="hover:text-news-accent transition-colors">Disclaimer</Link></li>
              <li><Link to="/contact" className="hover:text-news-accent transition-colors">Advertise with Us</Link></li>
            </ul>
          </div>

          <div>
             <h4 className="font-bold uppercase tracking-widest text-xs mb-6 text-gray-500">{t('newsletterTitle')}</h4>
             <p className="text-gray-400 text-xs mb-4">{t('newsletterDesc')}</p>
             <form className="flex flex-col space-y-2">
               <input type="email" placeholder="Email Address" className="bg-gray-800 border border-gray-700 text-white text-sm px-4 py-2 rounded-sm focus:outline-none focus:border-news-accent focus:ring-1 focus:ring-news-accent" />
               <button type="button" className="bg-news-accent text-white text-xs font-bold uppercase tracking-wider py-2 rounded-sm hover:bg-blue-700 transition-colors">{t('subscribe')}</button>
             </form>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-xs">
            &copy; {new Date().getFullYear()} CricFocus Media. {t('rightsReserved')}
          </p>
          <p className="text-gray-600 text-[10px] mt-2 md:mt-0">
            Images courtesy of Unsplash & Mixkit (Royalty Free).
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;