import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const BreakingNews: React.FC = () => {
  const { language } = useLanguage();

  const newsItems = language === 'HI' 
    ? [
        "ब्रेकिंग: विराट कोहली ने 81वां शतक जड़ा!",
        "IPL 2025: नीलामी 15 दिसंबर को दुबई में होगी।",
        "WTC फाइनल: भारत ने ऑस्ट्रेलिया को हराया, बना चैंपियन!",
        "जसप्रीत बुमराह बने ICC के नंबर 1 टेस्ट गेंदबाज।"
      ]
    : [
        "BREAKING: Virat Kohli smashes 81st International Century!",
        "IPL 2025: Mega Auction scheduled for Dec 15 in Dubai.",
        "WTC Final: India defeats Australia to claim the mace!",
        "Jasprit Bumrah reclaims No. 1 ICC Test Bowler ranking."
      ];

  return (
    <div className="bg-news-accent text-white text-xs sm:text-sm font-bold tracking-wide overflow-hidden flex items-center h-10 shadow-md">
      <div className="bg-red-600 h-full flex items-center px-4 z-10 shadow-lg shrink-0 uppercase tracking-widest">
        {language === 'HI' ? 'ताज़ा खबर' : 'Breaking'}
      </div>
      <div className="flex-1 overflow-hidden relative">
        <div className="whitespace-nowrap animate-marquee flex items-center h-full absolute top-0">
          {newsItems.map((item, index) => (
            <span key={index} className="mx-8 flex items-center">
              <span className="w-2 h-2 bg-white rounded-full mr-3 animate-pulse"></span>
              {item}
            </span>
          ))}
          {/* Duplicate for smooth loop */}
          {newsItems.map((item, index) => (
            <span key={`dup-${index}`} className="mx-8 flex items-center">
              <span className="w-2 h-2 bg-white rounded-full mr-3 animate-pulse"></span>
              {item}
            </span>
          ))}
        </div>
      </div>
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 30s linear infinite;
        }
        .animate-marquee:hover {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  );
};

export default BreakingNews;