import { TEAMS_DATA, MATCHES_DATA, COMMENTARY_DATA } from '../_CONTENT_MANAGER/matches';
import { ARTICLES_EN, ARTICLES_HI } from '../_CONTENT_MANAGER/articles';
import { VIDEOS_DATA } from '../_CONTENT_MANAGER/videos';

// Re-exporting data from the Content Manager so the rest of the app works
export const TEAMS = TEAMS_DATA;
export const MOCK_MATCHES = MATCHES_DATA;
// MOCK_ARTICLES points to English by default, but components should use MOCK_ARTICLES_EN or _HI
export const MOCK_ARTICLES = ARTICLES_EN;
export const MOCK_ARTICLES_EN = ARTICLES_EN;
export const MOCK_ARTICLES_HI = ARTICLES_HI;

export const MOCK_COMMENTARY = COMMENTARY_DATA;
export const MOCK_VIDEOS = VIDEOS_DATA;