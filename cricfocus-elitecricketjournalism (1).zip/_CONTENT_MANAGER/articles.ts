import { Article } from '../types';

// ==========================================
// ARTICLES & REVIEWS MANAGER
// ==========================================

export const ARTICLES_EN: Article[] = [
  {
    id: 'a1',
    title: 'Virat Kohli: When the King Plays, The World Stops',
    excerpt: 'Aggression, passion, and pure class. Kohli is not just a player; he is an emotion. Read about the defining moments when he proved the world wrong.',
    author: 'CricFocus Fan Desk',
    publishedAt: 'Trending Now',
    category: 'Superstar Feature',
    imageUrl: 'https://images.unsplash.com/photo-1624526267942-ab0ff8a3e972?q=80&w=2070&auto=format&fit=crop',
    content: `
      <p class="drop-cap"><strong>When Virat Kohli steps onto the cricket field, the very atmosphere changes.</strong> Critics talk about his aggression, but without fire, you cannot forge steel, and without aggression, you don't get Virat Kohli.</p>
      
      <p>Remember that match against Pakistan at the MCG? 90,000 people, Haris Rauf steaming in. Those two sixes... straight down the ground. It defied physics. On that day, Kohli proved that <em>form is temporary, but class is permanent.</em></p>

      <h3>The Chase Master</h3>
      <p>When the target is massive, other players crumble under pressure. But for the 'Chase Master', a different zone activates. The fire in his eyes, the sprint between wickets... it’s like a predator on the hunt.</p>

      <figure>
        <img src="https://images.unsplash.com/photo-1531415074968-0559f3f13e5e?auto=format&fit=crop&q=80&w=1000" class="w-full my-6 rounded-sm shadow-sm" alt="Stadium Atmosphere" />
        <figcaption class="text-xs text-gray-500 text-center italic mt-2 mb-6">The crowd chanting 'Kohli-Kohli'.</figcaption>
      </figure>

      <h3>Obsession with Fitness</h3>
      <p>There was a time when Virat loved his Chhole Bhature. Look at him now. Grilled chicken, black coffee, and unmatched discipline. This sacrifice makes him the G.O.A.T. Youngsters hit the gym because they see him; that is his true impact.</p>
      
      <p>Kohli doesn't just score runs; he represents India's new mindset - <strong>We Don't Just Play, We Dominate.</strong></p>
    `
  },
  {
    id: 'a2',
    title: 'Rohit Sharma: The "Hitman" Show - Lazy Elegance',
    excerpt: 'They say Rohit has extra time to bat. Is it really true? Or is it the invisible hard work behind the effortless grace?',
    author: 'Mumbai Cha Raja',
    publishedAt: '2 Hours Ago',
    category: 'Captaincy',
    imageUrl: 'https://images.unsplash.com/photo-1593341646782-e0b495cffd32?q=80&w=1000&auto=format&fit=crop',
    content: `
      <p>Hitman has a unique style. He doesn't hit the ball; he caresses it, and yet it lands in the stands. When Rohit is in form, batting looks ridiculously easy. It feels like he's playing gully cricket in international stadiums.</p>

      <figure>
        <img src="https://images.unsplash.com/photo-1593341646782-e0b495cffd32?auto=format&fit=crop&q=80&w=1000" class="w-full my-6 rounded-sm shadow-sm" alt="Street Cricket Passion" />
        <figcaption class="text-xs text-gray-500 text-center italic mt-2 mb-6">Where it all begins.</figcaption>
      </figure>

      <h3>Lazy Elegance? No, Pure Talent!</h3>
      <p>Critics call him lazy. But to score 264 runs in an ODI, you don't need laziness; you need grit! Rohit's pull shot is the most beautiful sight in cricket. The bowler bangs it short, and Rohit smiles as he deposits it over the ropes.</p>
      
      <p><strong>Captaincy Boss:</strong> Leading Mumbai Indians to 5 titles and now captaining Team India, his selfless batting in the 2023 World Cup showed he plays for the team, not milestones.</p>
    `
  },
  {
    id: 'a3',
    title: 'Rishabh Pant: The Miracle Return',
    excerpt: 'After the accident, no one thought Pant would return. But how could the boy who shattered Gabba\'s pride give up so easily?',
    author: 'Ravi Shastri Fan Club',
    publishedAt: 'Yesterday',
    category: 'Comeback Story',
    imageUrl: 'https://images.unsplash.com/photo-1512719994953-eabf50895df7?q=80&w=2000&auto=format&fit=crop',
    content: `
      <p>Life bowled him a yorker, but Rishabh Pant played a reverse sweep on it! Seeing the photos of that accident shook everyone's soul. We thought his career was over. But Spiderman returned!</p>

      <figure>
        <img src="https://images.unsplash.com/photo-1555862124-a5e7b233e56f?auto=format&fit=crop&q=80&w=1000" class="w-full my-6 rounded-sm shadow-sm" alt="Cricket Gear" />
        <figcaption class="text-xs text-gray-500 text-center italic mt-2 mb-6">Back in the kit, stronger than ever.</figcaption>
      </figure>

      <h3>Breaking the Gabba Pride</h3>
      <p>Who can forget that historic win in Australia? "Toota hai Gabba ka ghamand!" Pant's innings changed Indian cricket's self-belief. He plays without fear. Test match or T20, he plays his game. One-handed sixes are his signature.</p>
      
      <p>Now that he is back on the field, every run, every catch feels like a miracle. Welcome back, Pant!</p>
    `
  },
  {
    id: 'a4',
    title: 'Thala For A Reason: The Magic of MS Dhoni',
    excerpt: 'Even after retirement, his craze in the IPL is unmatched. What makes Dhoni stand apart from the rest?',
    author: 'Chennai Super Fan',
    publishedAt: 'Classic',
    category: 'Legend',
    imageUrl: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?q=80&w=2000&auto=format&fit=crop',
    content: `
      <p>Last over. 15 runs needed. MS Dhoni at the crease. Heart rate up? No way. <strong>If Thala is there, it is possible.</strong></p>
      
      <figure>
        <img src="https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&q=80&w=1000" class="w-full my-6 rounded-sm shadow-sm" alt="Stadium Lights" />
        <figcaption class="text-xs text-gray-500 text-center italic mt-2 mb-6">The roar when he walks out is deafening.</figcaption>
      </figure>

      <p>Dhoni is not just a cricketer; he is an institution. DRS is often called the "Dhoni Review System" for a reason. From behind the stumps, he reads the batsman's mind. His stumpings are faster than the speed of light.</p>
      <p>Win or lose, the expression remains calm. This is what makes him 'Captain Cool'. Generations will come and go, but there will never be another Mahi.</p>
    `
  },
  {
    id: 'a5',
    title: 'Jasprit Bumrah: The Batter\'s Nightmare',
    excerpt: 'That action, that yorker. Seeing Bumrah at the top of his mark makes even the best batsmen sweat.',
    author: 'Pace Is Pace Yaar',
    publishedAt: 'Analysis',
    category: 'Bowling',
    imageUrl: 'https://images.unsplash.com/photo-1589487391730-58f20eb2c308?q=80&w=2074&auto=format&fit=crop',
    content: `
      <p>Cricket is known as a batter's game, but Bumrah changed that perception. When "Boom Boom" starts his run-up, the stadium feels a different energy.</p>
      
      <figure>
        <img src="https://images.unsplash.com/photo-1589487391730-58f20eb2c308?auto=format&fit=crop&q=80&w=1000" class="w-full my-6 rounded-sm shadow-sm" alt="Cricket Ball Seam" />
        <figcaption class="text-xs text-gray-500 text-center italic mt-2 mb-6">Precision and pace.</figcaption>
      </figure>

      <p>His yorkers crush toes, and his slower balls crush spirits. Coming back from injury to prove he is the world's No. 1 bowler shows his character. India's bowling attack is incomplete without him.</p>
    `
  }
];

export const ARTICLES_HI: Article[] = [
  {
    id: 'a1',
    title: 'विराट कोहली: जब किंग खेलता है, तो दुनिया रुक जाती है',
    excerpt: 'आक्रामकता, जुनून और क्लास। कोहली सिर्फ एक खिलाड़ी नहीं, एक जज्बा हैं। पढ़िए उनके करियर के वो पल जब उन्होंने आलोचकों को गलत साबित किया।',
    author: 'क्रिकफोकस फैन डेस्क',
    publishedAt: 'अभी ट्रेंडिंग',
    category: 'सुपरस्टार फीचर',
    imageUrl: 'https://images.unsplash.com/photo-1624526267942-ab0ff8a3e972?q=80&w=2070&auto=format&fit=crop',
    content: `
      <p class="drop-cap"><strong>क्रिकेट के मैदान में जब विराट कोहली उतरता है, तो हवा का रुख बदल जाता है।</strong> लोग कहते हैं आक्रामकता ज्यादा है, पर भाई, बिना आग के खाना नहीं पकता और बिना जुनून के कोहली नहीं बनता।</p>
      
      <p>याद है वो पाकिस्तान वाला मैच? MCG का ग्राउंड, 90,000 लोग, और सामने हारिस रऊफ। वो दो छक्के... उफ्फ! वो शॉट्स देख के तो फिजिक्स भी कंफ्यूज हो गई थी। कोहली ने उस दिन दिखा दिया कि <em>फॉर्म टेंपरेरी है, पर क्लास परमानेंट है।</em></p>

      <h3>द चेज मास्टर</h3>
      <p>जब टारगेट बड़ा होता है, तब बाकी प्लेयर्स प्रेशर में आ जाते हैं, लेकिन चीकू भैया का अलग ही जोन ऑन हो जाता है। आंखों में वो अंगार, विकेटों के बीच वो तेजी... ऐसा लगता है शेर शिकार पे निकला है।</p>

      <figure>
        <img src="https://images.unsplash.com/photo-1531415074968-0559f3f13e5e?auto=format&fit=crop&q=80&w=1000" class="w-full my-6 rounded-sm shadow-sm" alt="स्टेडियम का माहौल" />
        <figcaption class="text-xs text-gray-500 text-center italic mt-2 mb-6">जब स्टेडियम में 'कोहली-कोहली' गूंजता है।</figcaption>
      </figure>

      <h3>फिटनेस का जुनून</h3>
      <p>एक समय था जब विराट को छोले भटूरे सबसे ज्यादा पसंद थे। आज देखो? ग्रिल्ड चिकन और ब्लैक कॉफी। ये त्याग ही उन्हें GOAT बनाता है। आज के युवा उन्हें देख के जिम जाते हैं, ये है उनका असली असर।</p>
      
      <p>कोहली सिर्फ रन नहीं बनाते, वो भारत की नई सोच को दर्शाते हैं - <strong>हम सिर्फ खेलते नहीं, हम राज करते हैं।</strong></p>
    `
  },
  {
    id: 'a2',
    title: 'रोहित शर्मा: हिटमैन का शो - वड़ा पाव से वर्ल्ड कप तक',
    excerpt: 'लोग कहते हैं रोहित के पास बैटिंग करने के लिए एक्स्ट्रा टाइम है। क्या सच में? या ये उनकी मेहनत है जो हमें दिखती नहीं?',
    author: 'मुंबई का राजा',
    publishedAt: '2 घंटे पहले',
    category: 'कप्तानी',
    imageUrl: 'https://images.unsplash.com/photo-1593341646782-e0b495cffd32?q=80&w=1000&auto=format&fit=crop',
    content: `
      <p>हिटमैन का स्टाइल ही अलग है। वो बॉल को मारते नहीं, सहलाते हैं, और बॉल सीधा स्टैंड्स में मिलती है। जब रोहित फॉर्म में होते हैं, तो बैटिंग बहुत आसान लगती है। ऐसा लगता है गली क्रिकेट चल रहा है।</p>

       <figure>
        <img src="https://images.unsplash.com/photo-1593341646782-e0b495cffd32?auto=format&fit=crop&q=80&w=1000" class="w-full my-6 rounded-sm shadow-sm" alt="Street Cricket Passion" />
        <figcaption class="text-xs text-gray-500 text-center italic mt-2 mb-6">गली क्रिकेट से शुरुआत।</figcaption>
      </figure>

      <h3>लेजी एलिगेंस? नहीं, प्योर टैलेंट!</h3>
      <p>आलोचक बोलते हैं वो लेजी है। अरे भाई, 264 रन वनडे में बनाने के लिए लेजी आदमी नहीं, जिगरा चाहिए! रोहित का पुल शॉट दुनिया का सबसे खूबसूरत नजारा है। बॉलर शॉर्ट बॉल डालता है, और रोहित स्माइल करके उसे बाउंड्री के पार भेज देते हैं।</p>
      
      <p><strong>कप्तानी का बॉस:</strong> मुंबई इंडियंस को 5 बार चैंपियन बनाना और अब टीम इंडिया को लीड करना, ये कोई मामूली बात नहीं। वर्ल्ड कप 2023 में जिस तरह उन्होंने निस्वार्थ बैटिंग की, वो दिखाता है कि बंदा टीम के लिए खेलता है, रिकॉर्ड के लिए नहीं।</p>
    `
  },
  {
    id: 'a3',
    title: 'ऋषभ पंत: मौत को छू के टक्क से वापस!',
    excerpt: 'एक्सीडेंट के बाद किसी ने नहीं सोचा था कि पंत वापस आएंगे। पर गाबा का घमंड तोड़ने वाला लड़का हार कैसे मान लेता?',
    author: 'रवि शास्त्री फैन क्लब',
    publishedAt: 'कल',
    category: 'वापसी की कहानी',
    imageUrl: 'https://images.unsplash.com/photo-1512719994953-eabf50895df7?q=80&w=2000&auto=format&fit=crop',
    content: `
      <p>जिंदगी ने उन्हें यॉर्कर मारी थी, पर ऋषभ पंत ने उस पे भी रिवर्स स्वीप मार दिया! वो एक्सीडेंट की फोटोज देख के सबकी रूह कांप गई थी। सबको लगा करियर खत्म। पर स्पाइडरमैन रिटर्न आ गया!</p>

      <figure>
        <img src="https://images.unsplash.com/photo-1555862124-a5e7b233e56f?auto=format&fit=crop&q=80&w=1000" class="w-full my-6 rounded-sm shadow-sm" alt="Cricket Gear" />
        <figcaption class="text-xs text-gray-500 text-center italic mt-2 mb-6">शेर की वापसी।</figcaption>
      </figure>

      <h3>गाबा का घमंड</h3>
      <p>कौन भूल सकता है वो ऐतिहासिक जीत ऑस्ट्रेलिया में? "टूटा है गाबा का घमंड!" पंत की वो इनिंग्स ने इंडियन क्रिकेट को बदल दिया। वो डरता नहीं है। टेस्ट मैच हो या टी20, वो अपना गेम खेलेगा। एक हाथ से छक्के मारना उसका शौक है।</p>
      
      <p>अब जब वो वापस फील्ड पे है, तो हर रन, हर कैच एक चमत्कार जैसा लगता है। वेलकम बैक, पंत!</p>
    `
  },
  {
    id: 'a4',
    title: 'थाला फॉर ए रीजन: धोनी का जादू कभी खत्म नहीं होता',
    excerpt: 'रिटायरमेंट के बाद भी आईपीएल में उनका क्रेज कम नहीं हुआ। क्या है धोनी में जो उन्हें सबसे अलग बनाता है?',
    author: 'चेन्नई सुपर फैन',
    publishedAt: 'क्लासिक',
    category: 'लेजेंड',
    imageUrl: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?q=80&w=2000&auto=format&fit=crop',
    content: `
      <p>आखरी ओवर। 15 रन चाहिए। क्रीज पे एमएस धोनी। धड़कनें तेज? नहीं भाई, <strong>थाला है तो मुमकिन है।</strong></p>

      <figure>
        <img src="https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&q=80&w=1000" class="w-full my-6 rounded-sm shadow-sm" alt="Stadium Lights" />
        <figcaption class="text-xs text-gray-500 text-center italic mt-2 mb-6">वो मैदान पर आते हैं, तो शोर थम जाता है।</figcaption>
      </figure>

      <p>धोनी सिर्फ क्रिकेटर नहीं, एक संस्था हैं। DRS का मतलब "धोनी रिव्यू सिस्टम" ऐसे ही नहीं पड़ा। विकेट्स के पीछे से वो बैट्समैन का दिमाग पढ़ लेते हैं। उनकी स्टंपिंग बिजली की गति से भी तेज होती है।</p>
      <p>चाहे जीतें या हारें, चेहरे पे वही शांति। यही चीज उन्हें 'कैप्टन कूल' बनाती है। पीढ़ियां आएंगी और जाएंगी, पर माही भाई जैसा कोई नहीं होगा।</p>
    `
  },
  {
    id: 'a5',
    title: 'जसप्रीत बुमराह: बल्लेबाजों का सबसे बड़ा दुःस्वप्न',
    excerpt: 'ऐसा एक्शन, ऐसी यॉर्कर। बुमराह को देख के अच्छे अच्छे बैट्समैन के पसीने छूट जाते हैं।',
    author: 'पेस इज़ पेस यार',
    publishedAt: 'विश्लेषण',
    category: 'बॉलिंग',
    imageUrl: 'https://images.unsplash.com/photo-1589487391730-58f20eb2c308?q=80&w=2074&auto=format&fit=crop',
    content: `
      <p>क्रिकेट बैटर का गेम माना जाता है, पर बुमराह ने ये सोच बदल दी। जब "बूम बूम" बॉलिंग रन-अप पे होता है, तो स्टेडियम में अलग ही एनर्जी होती है।</p>

      <figure>
        <img src="https://images.unsplash.com/photo-1589487391730-58f20eb2c308?auto=format&fit=crop&q=80&w=1000" class="w-full my-6 rounded-sm shadow-sm" alt="Cricket Ball Seam" />
        <figcaption class="text-xs text-gray-500 text-center italic mt-2 mb-6">रफ़्तार और सटीकता।</figcaption>
      </figure>

      <p>उनकी यॉर्कर्स पैर के अंगूठे तोड़ती हैं, और स्लोअर बॉल्स दिमाग। इंजरी के बाद वापस आके उन्होंने साबित किया कि वो दुनिया के नंबर 1 बॉलर क्यों हैं। भारत की बॉलिंग उनके बिना अधूरी है।</p>
    `
  }
];

// Default export (keep English as default for existing imports to work until updated)
export const ARTICLES_DATA = ARTICLES_EN;