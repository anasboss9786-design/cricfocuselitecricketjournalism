import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'EN' | 'HI';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const translations = {
  EN: {
    home: "Home",
    liveScore: "Live Score",
    news: "News",
    players: "Players",
    about: "About",
    contact: "Contact",
    latestAnalysis: "Latest Analysis",
    viewAll: "View All",
    editorsChoice: "Editor's Choice",
    featuredVideos: "Featured Videos",
    matchCenter: "Match Center",
    searchPlayer: "Search Player",
    searchDatabase: "Search Database",
    readMore: "Read More",
    published: "Published",
    shareStory: "Share this story",
    subscribe: "Subscribe",
    newsletterTitle: "CricFocus Weekly",
    newsletterDesc: "The finest cricket writing delivered to your inbox every Friday.",
    footerDesc: "CricFocus is the premier destination for modern cricket coverage. We combine data-driven analysis with world-class storytelling.",
    quickLinks: "Quick Links",
    legal: "Legal",
    followUs: "Follow Us",
    rightsReserved: "All rights reserved.",
    featuredBiography: "Featured Biography",
    ballByBall: "Ball by Ball"
  },
  HI: {
    home: "होम",
    liveScore: "लाइव स्कोर",
    news: "समाचार",
    players: "खिलाड़ी",
    about: "हमारे बारे में",
    contact: "संपर्क करें",
    latestAnalysis: "ताज़ा विश्लेषण",
    viewAll: "सभी देखें",
    editorsChoice: "संपादक की पसंद",
    featuredVideos: "प्रमुख वीडियो",
    matchCenter: "मैच सेंटर",
    searchPlayer: "खिलाड़ी खोजें",
    searchDatabase: "डेटाबेस खोजें",
    readMore: "पूरा पढ़ें",
    published: "प्रकाशित",
    shareStory: "शेयर करें",
    subscribe: "सब्सक्राइब करें",
    newsletterTitle: "क्रिकफोकस साप्ताहिक",
    newsletterDesc: "क्रिकेट की बेहतरीन खबरें, सीधे आपके इनबॉक्स में।",
    footerDesc: "क्रिकफोकस आधुनिक क्रिकेट कवरेज का प्रमुख स्थान है। हम डेटा-आधारित विश्लेषण और शानदार कहानियों को जोड़ते हैं।",
    quickLinks: "क्विक लिंक्स",
    legal: "कानूनी",
    followUs: "हमें फॉलो करें",
    rightsReserved: "सर्वाधिकार सुरक्षित।",
    featuredBiography: "प्रमुख जीवनी",
    ballByBall: "बॉल-दर-बॉल कमेंट्री"
  }
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Auto-detect India based on Timezone or Browser Language
  const [language, setLanguage] = useState<Language>(() => {
    try {
      const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
      // If user is in India Timezone
      if (timeZone === 'Asia/Kolkata' || timeZone === 'Asia/Calcutta') {
        return 'HI';
      }
      // Fallback: If browser language is set to Hindi
      if (navigator.language.toLowerCase().startsWith('hi')) {
        return 'HI';
      }
    } catch (e) {
      console.error("Error detecting location/language", e);
    }
    // Default to English for rest of world
    return 'EN';
  });

  const t = (key: string) => {
    // @ts-ignore
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};