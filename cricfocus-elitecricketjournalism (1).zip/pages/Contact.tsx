import React from 'react';
import { SITE_SETTINGS } from '../_CONTENT_MANAGER/settings';
import { Instagram, Twitter, Facebook, Youtube } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <div className="bg-news-paper min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        <h1 className="text-4xl font-serif font-bold text-news-ink mb-4">Contact CricFocus</h1>
        <p className="text-lg text-gray-600 mb-8">
          Have a question about a match? Want to advertise with us? Or just want to share your feedback? We'd love to hear from you.
        </p>

        <div className="bg-white p-8 border border-gray-200 shadow-sm rounded-sm">
          <form className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">First Name</label>
                <input type="text" className="w-full p-3 bg-gray-50 border border-gray-300 focus:border-news-accent focus:bg-white transition-colors outline-none" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">Last Name</label>
                <input type="text" className="w-full p-3 bg-gray-50 border border-gray-300 focus:border-news-accent focus:bg-white transition-colors outline-none" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">Email Address</label>
              <input type="email" className="w-full p-3 bg-gray-50 border border-gray-300 focus:border-news-accent focus:bg-white transition-colors outline-none" />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">Subject</label>
              <select className="w-full p-3 bg-gray-50 border border-gray-300 focus:border-news-accent focus:bg-white transition-colors outline-none">
                <option>General Inquiry</option>
                <option>Advertising / Sponsorship</option>
                <option>Report an Error</option>
                <option>Editorial Feedback</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">Message</label>
              <textarea rows={6} className="w-full p-3 bg-gray-50 border border-gray-300 focus:border-news-accent focus:bg-white transition-colors outline-none"></textarea>
            </div>

            <button type="submit" className="w-full bg-news-accent text-white font-bold uppercase tracking-widest py-4 hover:bg-blue-700 transition-colors">
              Send Message
            </button>
          </form>
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8 text-center">
          <div className="p-4 border border-gray-100 bg-white hover:shadow-md transition-shadow">
             <h3 className="font-bold text-lg mb-2">Editorial Team</h3>
             <p className="text-gray-500 text-sm">For press releases and corrections</p>
             <p className="text-news-accent font-bold mt-1">editor@cricfocus.com</p>
          </div>
          <div className="p-4 border border-gray-100 bg-white hover:shadow-md transition-shadow">
             <h3 className="font-bold text-lg mb-2">Business Inquiries</h3>
             <p className="text-gray-500 text-sm">For partnerships and advertising</p>
             <p className="text-news-accent font-bold mt-1">business@cricfocus.com</p>
          </div>
        </div>

        <div className="mt-12 text-center border-t border-gray-200 pt-12">
          <h3 className="font-bold uppercase tracking-widest text-xs text-gray-400 mb-6">Connect on Social Media</h3>
          <div className="flex justify-center space-x-8">
             {SITE_SETTINGS.socials.instagram && (
               <a href={SITE_SETTINGS.socials.instagram} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center group">
                 <div className="p-3 bg-gray-100 rounded-full group-hover:bg-gradient-to-r group-hover:from-purple-500 group-hover:to-pink-500 transition-all">
                   <Instagram className="w-6 h-6 text-gray-600 group-hover:text-white" />
                 </div>
                 <span className="text-xs font-bold mt-2 text-gray-500 group-hover:text-pink-600">Instagram</span>
               </a>
             )}
             {SITE_SETTINGS.socials.twitter && (
               <a href={SITE_SETTINGS.socials.twitter} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center group">
                 <div className="p-3 bg-gray-100 rounded-full group-hover:bg-blue-400 transition-all">
                   <Twitter className="w-6 h-6 text-gray-600 group-hover:text-white" />
                 </div>
                 <span className="text-xs font-bold mt-2 text-gray-500 group-hover:text-blue-500">Twitter</span>
               </a>
             )}
             {SITE_SETTINGS.socials.facebook && (
               <a href={SITE_SETTINGS.socials.facebook} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center group">
                 <div className="p-3 bg-gray-100 rounded-full group-hover:bg-blue-700 transition-all">
                   <Facebook className="w-6 h-6 text-gray-600 group-hover:text-white" />
                 </div>
                 <span className="text-xs font-bold mt-2 text-gray-500 group-hover:text-blue-700">Facebook</span>
               </a>
             )}
              {SITE_SETTINGS.socials.youtube && (
               <a href={SITE_SETTINGS.socials.youtube} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center group">
                 <div className="p-3 bg-gray-100 rounded-full group-hover:bg-red-600 transition-all">
                   <Youtube className="w-6 h-6 text-gray-600 group-hover:text-white" />
                 </div>
                 <span className="text-xs font-bold mt-2 text-gray-500 group-hover:text-red-600">YouTube</span>
               </a>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;