import React, { useState } from 'react';
import { MOCK_MATCHES } from '../services/mockData';
import { MatchFormat, MatchStatus } from '../types';
import { useNavigate } from 'react-router-dom';
import { Filter, Calendar } from 'lucide-react';

const Scores: React.FC = () => {
  const [filter, setFilter] = useState<MatchFormat | 'ALL'>('ALL');
  const navigate = useNavigate();

  const filteredMatches = filter === 'ALL' 
    ? MOCK_MATCHES 
    : MOCK_MATCHES.filter(m => m.format === filter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 min-h-screen">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
        <h1 className="text-3xl font-serif font-bold text-news-ink">Match Center</h1>
        
        {/* Filter Controls */}
        <div className="flex items-center space-x-2 overflow-x-auto">
          <Filter className="w-4 h-4 text-gray-400 mr-2" />
          {(['ALL', MatchFormat.TEST, MatchFormat.ODI, MatchFormat.T20] as Array<MatchFormat | 'ALL'>).map((fmt) => (
            <button
              key={fmt}
              onClick={() => setFilter(fmt)}
              className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider transition-colors ${
                filter === fmt 
                  ? 'bg-news-ink text-white' 
                  : 'bg-white border border-gray-300 text-gray-600 hover:bg-gray-50'
              }`}
            >
              {fmt}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMatches.map(match => (
          <div 
            key={match.id} 
            onClick={() => navigate(`/match/${match.id}`)}
            className="bg-white border border-gray-200 rounded-sm hover:shadow-md transition-shadow cursor-pointer flex flex-col h-full"
          >
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
               <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">{match.format}</span>
               <span className={`text-xs font-bold uppercase tracking-widest ${match.status === MatchStatus.LIVE ? 'text-news-accent animate-pulse' : 'text-gray-400'}`}>
                 {match.status}
               </span>
            </div>
            
            <div className="p-6 flex-grow">
               {/* Home Team */}
               <div className="flex justify-between items-center mb-4">
                 <div className="flex items-center space-x-3">
                   <img src={match.teamHome.flag} alt="" className="w-6 h-4 object-cover shadow-sm" />
                   <span className="font-bold text-lg text-gray-900">{match.teamHome.name}</span>
                 </div>
                 {match.scoreHome && (
                   <div className="text-right">
                     <span className="font-mono font-bold text-lg">{match.scoreHome.runs}/{match.scoreHome.wickets}</span>
                   </div>
                 )}
               </div>

               {/* Away Team */}
               <div className="flex justify-between items-center mb-4">
                 <div className="flex items-center space-x-3">
                   <img src={match.teamAway.flag} alt="" className="w-6 h-4 object-cover shadow-sm" />
                   <span className="font-bold text-lg text-gray-900">{match.teamAway.name}</span>
                 </div>
                 {match.scoreAway && (
                   <div className="text-right">
                     <span className="font-mono font-bold text-lg">{match.scoreAway.runs}/{match.scoreAway.wickets}</span>
                   </div>
                 )}
               </div>

               <p className="text-xs text-news-accent mt-4 font-medium">
                 {match.result || match.summary}
               </p>
            </div>

            <div className="px-6 py-3 bg-gray-50 border-t border-gray-100 text-xs text-gray-500 flex items-center">
              <Calendar className="w-3 h-3 mr-2" />
              {new Date(match.startTime).toLocaleDateString()} &bull; {match.venue}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Scores;